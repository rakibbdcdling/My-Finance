# PythonAnywhere-তে নিরাপদে আপডেট করার বাংলা নির্দেশিকা

## সবচেয়ে জরুরি সতর্কতা

- এই Release ZIP-এ **`finance.db` নেই**। এটি ইচ্ছাকৃত, যাতে কোড আপডেটের সময় আপনার লাইভ Database overwrite না হয়।
- ZIP-এ `.env`, `instance/.secret_key`, কোনো Password বা SMTP Secret নেই।
- ZIP আপলোড করলেই হারানো User/Transaction ফিরে আসবে না। পুরোনো Database অবশ্যই Backup থেকে Restore করতে হবে।
- নতুন ZIP extract করার আগে পুরোনো Database-এর আলাদা Backup রাখবেন।

---

## ধাপ ১ — পুরোনো Database উদ্ধার/Restore করুন (আগে এটি করুন)

আপনি যদি নতুন ZIP-এর `finance.db` দিয়ে পুরোনো ফাইল Replace করে থাকেন, তাহলে বর্তমান Database-এ পুরোনো User/Transaction নাও থাকতে পারে।

1. PythonAnywhere → **Files** খুলুন।
2. `/home/myfinanceapp/finance/finance.db` ফাইলটি এখনকার অবস্থায় Download করে বা Bash দিয়ে কপি করে রাখুন।
3. PythonAnywhere Support-এ আগের `finance.db`-এর Backup Restore করার অনুরোধ করুন। Restore করতে বলবেন আলাদা নামে, যেমন `finance.db.recovered`।
4. Support থেকে Restore পাওয়া গেলে নিচের Command দিয়ে recovered DB পরীক্ষা করুন।

```bash
cd /home/myfinanceapp/finance
python - <<'PY'
import sqlite3
p = 'finance.db.recovered'
c = sqlite3.connect(p)
print('tables:', c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall())
for t in ('users', 'records', 'settlements'):
    try:
        print(t, c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0])
    except Exception as e:
        print(t, 'not available:', e)
try:
    print('users:', c.execute('SELECT email, role, status FROM users').fetchall())
except Exception as e:
    print('user listing unavailable:', e)
c.close()
PY
```

**শুধু তখনই** recovered DB-তে আপনার পুরোনো User এবং Transaction দেখা গেলে বর্তমান DB-এর Backup নিয়ে recovered ফাইলটি Live DB করুন:

```bash
cd /home/myfinanceapp/finance
cp finance.db finance.db.before_restore_$(date +%Y%m%d_%H%M%S).bak
cp finance.db.recovered finance.db
```

যদি Support Backup না পায়, নিজের PC/Download/পুরোনো server copy/অন্য Backup-এ `finance.db` খুঁজুন। পুরোনো DB কোথাও না থাকলে শুধু নতুন Code ZIP দিয়ে পুরোনো Password বা Financial Data উদ্ধার করা সম্ভব নয়।

---

## ধাপ ২ — Live Database ও Secret Key-এর Backup নিন

পুরোনো DB Restore নিশ্চিত হওয়ার পর:

```bash
cd /home/myfinanceapp/finance
mkdir -p backups
python - <<'PY'
import sqlite3, time, os
source = 'finance.db'
target = 'backups/finance-before-code-update-' + time.strftime('%Y%m%d-%H%M%S') + '.db'
if not os.path.isfile(source):
    raise SystemExit('STOP: finance.db পাওয়া যায়নি; ZIP extract করবেন না।')
src = sqlite3.connect(source)
dst = sqlite3.connect(target)
src.backup(dst)
dst.close(); src.close()
print('Database backup:', target)
PY
```

`instance/.secret_key` থাকলে সেটিও রেখে দিন। এটি Delete/Replace করবেন না:

```bash
mkdir -p backups
if [ -f instance/.secret_key ]; then cp instance/.secret_key backups/secret_key.before-update; fi
```

---

## ধাপ ৩ — নতুন ZIP Upload ও Extract করুন

1. এই Release ZIP আপনার PC-তে Download করুন।
2. PythonAnywhere → **Files** → `/home/myfinanceapp/`-এ ZIP Upload করুন। ফাইলের নাম দিন `finance_release.zip`।
3. Bash Console খুলে চালান:

```bash
cd /home/myfinanceapp/finance
unzip -l /home/myfinanceapp/finance_release.zip | head -40
```

তালিকায় `app.py`, `templates/`, `static/`, `requirements.txt` থাকবে। `finance.db` থাকা **উচিত নয়**।

তারপর:

```bash
unzip -o /home/myfinanceapp/finance_release.zip -d /home/myfinanceapp/finance
```

ZIP-এ Database নেই, তাই আপনার Live `finance.db` overwrite হবে না। `instance/.secret_key`-ও ZIP-এ নেই, তাই পুরোনো Secret Key অক্ষত থাকবে।

---

## ধাপ ৪ — সঠিক Virtualenv-এ Dependency Install করুন

আপনার Virtualenv path:
`/home/myfinanceapp/.virtualenvs/finance-env`

এই Command-গুলো চালান:

```bash
/home/myfinanceapp/.virtualenvs/finance-env/bin/python -m pip install -r /home/myfinanceapp/finance/requirements.txt
/home/myfinanceapp/.virtualenvs/finance-env/bin/python -c "import flask, openpyxl; print('Flask:', flask.__version__); print('openpyxl:', openpyxl.__version__)"
```

---

## ধাপ ৫ — আগের SMTP সেটিংস WSGI-তে দিন

এই Release-এ Gmail OAuth/API নেই। Signup verification, Forgot Password এবং Master Admin OTP—তিনটিই আগের SMTP configuration দিয়েই পাঠানো হবে। আগে যে SMTP credentials দিয়ে Email পাঠানো কাজ করছিল, সেই একই Host, Port, Username, Password ও Sender ব্যবহার করুন।

PythonAnywhere → **Web** → **Code** → WSGI configuration file খুলুন। `from app import app as application` লাইনের **আগে** নিচের Environment Settings বসান। Placeholder-গুলো আপনার আগের কাজ করা SMTP তথ্য দিয়ে বদলাবেন।

```python
import os

# Finance database: অবশ্যই আপনার পুরোনো/Restore করা Live DB path
os.environ['FINANCE_DB_PATH'] = '/home/myfinanceapp/finance/finance.db'
os.environ['FINANCE_SECRET_KEY'] = 'এখানে-নিজের-দীর্ঘ-random-secret-দিন'
os.environ['FINANCE_COOKIE_SECURE'] = '1'
os.environ['MASTER_ADMIN_EMAIL'] = 'আপনার-admin-inbox@example.com'

# আপনার আগের SMTP configuration
os.environ['SMTP_HOST'] = 'আপনার-আগের-SMTP-host'
os.environ['SMTP_PORT'] = '587'
os.environ['SMTP_USERNAME'] = 'আপনার-SMTP-username'
os.environ['SMTP_PASSWORD'] = 'আপনার-SMTP-password'
os.environ['SMTP_FROM'] = 'আপনার-sender-email'
os.environ['SMTP_USE_SSL'] = '0'  # STARTTLS হলে 0; implicit SSL হলে 1

# এরপর WSGI-এর আগের sys.path সেটআপ রাখুন এবং শেষে:
from app import app as application
```

**গুরুত্বপূর্ণ:** আপনার আগের SMTP Port/SSL mode যদি আলাদা হয়ে থাকে, সেটিই অপরিবর্তিত রাখবেন। Port 587 সাধারণত STARTTLS (`SMTP_USE_SSL=0`), আর implicit SSL ব্যবহারে সাধারণত Port 465 ও `SMTP_USE_SSL=1` হয়। আপনার আগের কাজ করা configuration-ই অগ্রাধিকার পাবে। আসল SMTP Password বা Secret Key কাউকে Chat-এ পাঠাবেন না এবং GitHub-এ রাখবেন না।

**PythonAnywhere নোট:** আপনার আগের SMTP যদি এই একই PythonAnywhere account-এ কাজ করে থাকে, একই configuration রাখুন। Hosting-এর outbound SMTP policy/network access পরিবর্তিত হলে Error Log পরীক্ষা করতে হবে; Gmail OAuth সেটআপের প্রয়োজন নেই।

## ধাপ ৬ — WSGI Import ও Database যাচাই করুন

প্রথমে নিশ্চিত করুন Database ফাইল আছে:

```bash
cd /home/myfinanceapp/finance
ls -lh finance.db
```

তারপর সঠিক Virtualenv দিয়ে App Import করুন:

```bash
/home/myfinanceapp/.virtualenvs/finance-env/bin/python -c "import sys; sys.path.insert(0, '/home/myfinanceapp/finance'); import app; print('APP:', app.__file__); print('DB:', app.DB_NAME)"
```

এটি App Import করবে এবং `init_db()`-এর মাধ্যমে প্রয়োজনীয় নতুন Table/Schema migration চালাবে। এর আগে অবশ্যই Database Backup রাখবেন।

Table ও User যাচাই:

```bash
/home/myfinanceapp/.virtualenvs/finance-env/bin/python - <<'PY'
import sys, sqlite3
sys.path.insert(0, '/home/myfinanceapp/finance')
import app
c = sqlite3.connect(str(app.DB_NAME))
print('tables:', c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall())
for t in ('users', 'records', 'settlements', 'password_reset_otps'):
    print(t, c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0])
try:
    print('accounts:', c.execute("SELECT email, role, status FROM users ORDER BY created_at").fetchall())
except Exception as e:
    print('Account check error:', e)
print('integrity:', c.execute('PRAGMA integrity_check').fetchone()[0])
c.close()
PY
```

আপনার পুরোনো User ও Record-এর সংখ্যা/Email Restore করা DB-র সঙ্গে মেলে কি না যাচাই করুন।

---

## ধাপ ৭ — PythonAnywhere Web App Reload

1. PythonAnywhere → **Web** খুলুন।
2. Virtualenv field-এ নিশ্চিত করুন:

```text
/home/myfinanceapp/.virtualenvs/finance-env
```

3. Source code এবং Working directory:

```text
/home/myfinanceapp/finance
```

4. **Reload** চাপুন।
5. ওয়েবসাইট খুলে আগের User Email ও Password দিয়ে Login পরীক্ষা করুন।

---

## ধাপ ৮ — SMTP OTP ও Forgot Password পরীক্ষা

1. আগে একটি বিদ্যমান সাধারণ User-এর Email/Password দিয়ে Login করুন।
2. Logout করে Forgot Password খুলুন।
3. সেই User-এর Email দিন এবং Send Code চাপুন।
4. আপনার SMTP sender account-এর Sent/Delivery status এবং প্রাপকের Inbox/Spam পরীক্ষা করুন।
5. ৬ ডিজিটের Code দিয়ে নতুন Password দিন। Code ৫ মিনিটের মধ্যে ব্যবহার করুন।
6. নতুন Password দিয়ে Login করুন।
7. Master Admin OTP-এর জন্য `MASTER_ADMIN_EMAIL`-এ Code যাচ্ছে কি না পরীক্ষা করুন।

Email না গেলে PythonAnywhere-এর Error Log-এর নতুন Traceback দেখুন। SMTP error হলে WSGI settings ও hosting-এর outbound SMTP access পরীক্ষা করুন।

---

## ধাপ ৯ — আপডেটের পরে যা পরীক্ষা করবেন

- পুরোনো User Login এবং তাদের পুরোনো Transactions অক্ষত আছে।
- Date সব জায়গায় `16 Nov, 2026 14:30:00`-এর মতো একই Format-এ আছে।
- Master Admin থেকে User-এর Dashboard/Income/Expenses/Other Tabs দেখা যায় এবং Close করা যায়।
- User নিজের CSV ও Excel Export করতে পারেন।
- Master Admin প্রত্যেক User-এর CSV ও Excel Export করতে পারেন।
- Forgot Password Code Email-এ যায় এবং Reset-এর পরে নতুন Password কাজ করে।
- Existing Income/Expense/Payable/Receivable/Settlement Calculation আগের মতো আছে।

কোনো ধাপে সমস্যা হলে Database Backup রেখে দিন এবং Error Log-এর নতুন Traceback দেখে পরবর্তী পদক্ষেপ নিন। Database Delete/Replace করবেন না।
