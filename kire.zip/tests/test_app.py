"""API regression tests. Run with: python -m unittest discover -s tests -v"""
import os, sys, tempfile, unittest
from unittest.mock import patch
from pathlib import Path
TMP = tempfile.TemporaryDirectory(prefix='finance-tests-')
os.environ['FINANCE_DB_PATH'] = str(Path(TMP.name) / 'test.db')
os.environ['FINANCE_SECRET_KEY'] = 'test-secret'
os.environ['FINANCE_PASSWORD'] = 'password123'
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app as finance_app

class FinanceLedgerTests(unittest.TestCase):
    def setUp(self):
        self.client = finance_app.app.test_client()
        with finance_app.get_db() as conn:
            conn.execute('DELETE FROM settlements'); conn.execute('DELETE FROM records'); conn.execute('DELETE FROM meta_options')
            conn.execute("""INSERT INTO users(id,full_name,email,phone,password_hash,role,status)
                VALUES('test_admin','Test Admin','test-admin@example.com','',
                       ?, 'user', 'active')
                ON CONFLICT(id) DO UPDATE SET password_hash=excluded.password_hash,status='active'""",
                (finance_app.generate_password_hash('password123'),))
        self.client.post('/api/auth/login', json={'email':'test-admin@example.com','password':'password123'})

    def create(self, kind, amount, method='Meghna Bank'):
        return self.client.post('/api/records', json={'type':kind,'date':'2026-11-13T07:30','amount':amount,'method':method,'name':'Test Person','status':'Unpaid'})

    def records(self): return self.client.get('/api/records').get_json()

    def test_payable_received_adds_account_and_partial_repayment_is_new_entry(self):
        income=self.client.post('/api/records',json={'type':'income','date':'2026-11-13T07:00','amount':10000,'method':'Meghna Bank','source':'Salary'})
        self.assertEqual(income.status_code,201)
        loan=self.create('payable',1000); self.assertEqual(loan.status_code,201)
        row=self.records()['payables'][0]
        self.assertEqual(row['outstanding'],1000)
        self.assertEqual(row['settled'],0)
        first=self.client.post(f"/api/records/{row['id']}/settlements",json={'date':'2026-11-13T08:00','amount':400,'method':'Meghna Bank'})
        self.assertEqual(first.status_code,201)
        row=self.records()['payables'][0]
        self.assertEqual(row['outstanding'],600)
        self.assertEqual(len(row['settlements']),1)
        second=self.client.post(f"/api/records/{row['id']}/settlements",json={'date':'2026-11-13T09:00','amount':600,'method':'Meghna Bank'})
        self.assertEqual(second.status_code,201)
        row=self.records()['payables'][0]
        self.assertEqual(row['outstanding'],0)
        self.assertEqual(len(row['settlements']),2)

    def test_receivable_reduces_account_and_partial_collection_adds_it_back(self):
        row=self.create('receivable',1000).get_json()
        self.assertTrue(row['success'])
        rec=self.records()['receivables'][0]
        self.assertEqual(rec['outstanding'],1000)
        self.assertEqual(self.client.post(f"/api/records/{rec['id']}/settlements",json={'date':'2026-11-13T08:00','amount':250,'method':'Bkash'}).status_code,201)
        rec=self.records()['receivables'][0]
        self.assertEqual(rec['outstanding'],750)
        self.assertEqual(rec['settlements'][0]['method'],'Bkash')

    def test_overpayment_and_principal_edit_are_rejected(self):
        rec=self.create('payable',500).get_json()
        rid=self.records()['payables'][0]['id']
        self.assertEqual(self.client.post(f'/api/records/{rid}/settlements',json={'date':'2026-11-13T08:00','amount':501,'method':'Meghna Bank'}).status_code,400)
        self.assertEqual(self.client.put(f'/api/records/{rid}',json={'date':'2026-11-13T08:00','amount':500,'method':'Meghna Bank','name':'Changed'}).status_code,400)

    def test_delete_removes_record_and_linked_settlements(self):
        row=self.create('payable',1000).get_json()
        rid=self.records()['payables'][0]['id']
        settlement=self.client.post(f'/api/records/{rid}/settlements',json={'date':'2026-11-13T08:00','amount':250,'method':'Meghna Bank'})
        self.assertEqual(settlement.status_code,201)
        deleted=self.client.delete(f'/api/records/{rid}')
        self.assertEqual(deleted.status_code,200)
        self.assertTrue(deleted.get_json()['database_compacted'])
        self.assertEqual(len(self.records()['payables']),0)
        with finance_app.get_db() as conn:
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM settlements WHERE parent_id=?',(rid,)).fetchone()[0],0)
            self.assertEqual(conn.execute('PRAGMA integrity_check').fetchone()[0],'ok')

    def test_delete_supported_for_each_tab_record_type(self):
        samples = [
            {'type':'income','date':'2026-11-13T07:00','amount':100,'method':'Cash','source':'Salary'},
            {'type':'expense','date':'2026-11-13T07:00','amount':50,'method':'Cash','category':'Meal Cost'},
            {'type':'payable','date':'2026-11-13T07:00','amount':200,'method':'Cash','name':'Payee'},
            {'type':'receivable','date':'2026-11-13T07:00','amount':300,'method':'Cash','name':'Customer'},
            {'type':'bankTxn','date':'2026-11-13T07:00','amount':400,'method':'Cash','note':'Deposit'},
        ]
        for sample in samples:
            created=self.client.post('/api/records',json=sample)
            self.assertEqual(created.status_code,201,created.get_json())
            rid=created.get_json()['id']
            self.assertEqual(self.client.delete(f'/api/records/{rid}').status_code,200)
        self.assertEqual(sum(len(v) for v in self.records().values()),0)
        self.assertEqual(self.client.delete('/api/records/missing').status_code,404)
        self.assertEqual(self.client.patch('/api/records/missing/status').status_code,404)

    def request_signup_code(self, payload):
        with patch.object(finance_app, 'validate_signup_email', return_value=(True, 'valid', '')), \
             patch.object(finance_app, 'send_email_otp') as sender:
            response = self.client.post('/api/auth/signup/request-code', json=payload)
            code = sender.call_args.args[1] if sender.called else None
        return response, code

    def verify_signup_code(self, email, code):
        return self.client.post('/api/auth/signup/verify-code', json={'email': email, 'code': code})

    def test_signup_and_user_data_isolation(self):
        self.client.post('/api/auth/logout')
        payload = {'fullName': 'User One', 'email': 'one@example.com', 'phone': '01700000000',
                   'password': 'strongpass123', 'confirmPassword': 'strongpass123'}
        signup, code = self.request_signup_code(payload)
        self.assertEqual(signup.status_code, 200)
        self.assertIn('Please check your email', signup.get_json()['message'])
        self.assertEqual(self.verify_signup_code(payload['email'], code).status_code, 201)
        own = self.client.post('/api/records', json={
            'type':'income','date':'2026-11-13T07:00','amount':1234,'method':'Cash','source':'Salary'
        })
        self.assertEqual(own.status_code, 201)
        self.client.post('/api/auth/logout')
        login = self.client.post('/api/auth/login', json={'email':'one@example.com','password':'strongpass123'})
        self.assertEqual(login.status_code, 200)
        self.assertEqual(len(self.client.get('/api/records').get_json()['incomes']), 1)
        self.client.post('/api/auth/logout')
        self.client.post('/api/auth/login', json={'email':'test-admin@example.com','password':'password123'})
        self.assertEqual(len(self.client.get('/api/records').get_json()['incomes']), 0)

    def test_signup_rejects_duplicate_email_and_password_mismatch(self):
        payload = {'fullName':'User Two','email':'two@example.com','phone':'01800000000',
                   'password':'strongpass123','confirmPassword':'strongpass123'}
        response, code = self.request_signup_code(payload)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.verify_signup_code(payload['email'], code).status_code, 201)
        self.client.post('/api/auth/logout')
        self.assertEqual(self.request_signup_code(payload)[0].status_code, 409)
        payload['email'] = 'three@example.com'
        payload['confirmPassword'] = 'different123'
        self.assertEqual(self.request_signup_code(payload)[0].status_code, 400)

    def test_signup_requires_correct_otp_before_creating_user(self):
        payload = {'fullName':'User Three','email':'three@example.com','phone':'01900000000',
                   'password':'strongpass123','confirmPassword':'strongpass123'}
        response, code = self.request_signup_code(payload)
        self.assertEqual(response.status_code, 200)
        wrong_code = '999999' if code != '999999' else '000000'
        self.assertEqual(self.verify_signup_code(payload['email'], wrong_code).status_code, 401)
        with finance_app.get_db() as conn:
            self.assertIsNone(conn.execute('SELECT 1 FROM users WHERE email=?', (payload['email'],)).fetchone())
        self.assertEqual(self.verify_signup_code(payload['email'], code).status_code, 201)

    def test_master_admin_otp_response_never_discloses_destination(self):
        with patch.object(finance_app, 'send_master_admin_otp'):
            response = self.client.post('/api/master-admin/request-code', json={})
        self.assertEqual(response.status_code, 200)
        self.assertNotIn(finance_app.MASTER_ADMIN_EMAIL, response.get_data(as_text=True))
        self.assertIn('Please check your admin email', response.get_json()['message'])

    def test_master_admin_can_view_user_finance_tabs_and_settlements(self):
        payload = {'fullName':'Detail User','email':'detail@example.com','phone':'01700000000',
                   'password':'strongpass123','confirmPassword':'strongpass123'}
        _, code = self.request_signup_code(payload)
        self.assertEqual(self.verify_signup_code(payload['email'], code).status_code, 201)
        self.client.post('/api/records', json={'type':'income','date':'2026-11-13T07:00','amount':500,'method':'Cash','source':'Salary'})
        self.client.post('/api/records', json={'type':'payable','date':'2026-11-13T07:00','amount':200,'method':'Cash','name':'Vendor'})
        payable_id = self.client.get('/api/records').get_json()['payables'][0]['id']
        self.client.post(f'/api/records/{payable_id}/settlements', json={'date':'2026-11-13T08:00','amount':50,'method':'Cash'})
        self.client.post('/api/auth/logout')
        with self.client.session_transaction() as sess:
            sess['user'] = {'id':'usr_legacy_admin','username':'admin@localhost','name':'Master Admin','email':'admin@localhost','role':'master_admin'}
        users = self.client.get('/api/master-admin/overview').get_json()['users']
        detail_user = next(u for u in users if u['email'] == 'detail@example.com')
        response = self.client.get(f"/api/master-admin/users/{detail_user['id']}/data")
        self.assertEqual(response.status_code, 200)
        body = response.get_json()
        self.assertEqual(len(body['records']), 2)
        self.assertEqual(len(body['settlements']), 1)

    def test_master_admin_permanently_deletes_user_and_all_owned_data(self):
        payload = {'fullName':'Delete User','email':'delete@example.com','phone':'01700000000',
                   'password':'strongpass123','confirmPassword':'strongpass123'}
        _, code = self.request_signup_code(payload)
        self.assertEqual(self.verify_signup_code(payload['email'], code).status_code, 201)
        self.client.post('/api/records', json={'type':'income','date':'2026-11-13T07:00','amount':500,'method':'Cash','source':'Salary'})
        self.client.post('/api/records', json={'type':'payable','date':'2026-11-13T07:00','amount':200,'method':'Cash','name':'Vendor'})
        payable_id = self.client.get('/api/records').get_json()['payables'][0]['id']
        self.client.post(f'/api/records/{payable_id}/settlements', json={'date':'2026-11-13T08:00','amount':50,'method':'Cash'})
        self.client.post('/api/auth/logout')
        with self.client.session_transaction() as sess:
            sess['user'] = {'id':'usr_legacy_admin','username':'admin@localhost','name':'Master Admin','email':'admin@localhost','role':'master_admin'}
        with finance_app.get_db() as conn:
            user_id = conn.execute('SELECT id FROM users WHERE email=?', ('delete@example.com',)).fetchone()['id']
        response = self.client.delete(f'/api/master-admin/users/{user_id}')
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()['database_compacted'])
        with finance_app.get_db() as conn:
            self.assertIsNone(conn.execute('SELECT 1 FROM users WHERE id=?', (user_id,)).fetchone())
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM records WHERE user_id=?', (user_id,)).fetchone()[0], 0)
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM settlements WHERE parent_id=?', (payable_id,)).fetchone()[0], 0)
            self.assertEqual(conn.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
        self.assertEqual(self.client.delete(f'/api/master-admin/users/{user_id}').status_code, 404)

    def test_master_admin_can_manage_email_domain_rules(self):
        with self.client.session_transaction() as sess:
            sess['user'] = {'id':'usr_legacy_admin','username':'admin@localhost',
                            'name':'Master Admin','email':'admin@localhost','role':'master_admin'}
        blocked = self.client.post('/api/master-admin/email-protection/rules', json={'domain':'temp.example','action':'block'})
        self.assertEqual(blocked.status_code, 200)
        listed = self.client.get('/api/master-admin/email-protection')
        self.assertEqual(listed.status_code, 200)
        self.assertTrue(any(x['domain'] == 'temp.example' and x['rule'] == 'block' for x in listed.get_json()['custom_rules']))
        allowed = self.client.post('/api/master-admin/email-protection/rules', json={'domain':'trusted.example','action':'allow'})
        self.assertEqual(allowed.status_code, 200)
        removed = self.client.post('/api/master-admin/email-protection/rules', json={'domain':'temp.example','action':'remove'})
        self.assertEqual(removed.status_code, 200)
        self.assertFalse(any(x['domain'] == 'temp.example' for x in self.client.get('/api/master-admin/email-protection').get_json()['custom_rules']))

    def test_disposable_domain_match_is_exact_or_subdomain_only(self):
        entries = {'tempmail.example'}
        self.assertTrue(finance_app._domain_matches('tempmail.example', entries))
        self.assertTrue(finance_app._domain_matches('mx.tempmail.example', entries))
        self.assertFalse(finance_app._domain_matches('nottempmail.example', entries))


    def test_date_formats_normalize_to_day_month_every_time(self):
        self.assertEqual(finance_app.validate_date('Nov 16, 2026 14:30:00'), '16 Nov, 2026 14:30:00')
        self.assertEqual(finance_app.validate_date('2026-11-16T14:30'), '16 Nov, 2026 14:30:00')
        self.assertEqual(finance_app.validate_date('16 Nov, 2026 14:30:00'), '16 Nov, 2026 14:30:00')

    def test_forgot_password_code_resets_existing_user_password(self):
        with finance_app.get_db() as conn:
            conn.execute("INSERT OR REPLACE INTO users(id,full_name,email,phone,password_hash,role,status) VALUES(?,?,?,?,?,?,?)",
                         ('forgot_user','Forgot User','forgot@example.com','01700000000',
                          finance_app.generate_password_hash('oldpassword123'),'user','active'))
        with patch.object(finance_app, 'send_email_otp') as sender:
            requested = self.client.post('/api/auth/forgot-password/request-code', json={'email':'forgot@example.com'})
            self.assertEqual(requested.status_code, 200)
            code = sender.call_args.args[1]
        reset = self.client.post('/api/auth/forgot-password/reset', json={
            'email':'forgot@example.com','code':code,'password':'newpassword123'
        })
        self.assertEqual(reset.status_code, 200, reset.get_json())
        self.client.post('/api/auth/logout')
        login = self.client.post('/api/auth/login', json={'email':'forgot@example.com','password':'newpassword123'})
        self.assertEqual(login.status_code, 200, login.get_json())

    def test_smtp_sender_uses_configured_smtp(self):
        with patch.dict(os.environ, {
            'SMTP_HOST':'smtp.example.com', 'SMTP_PORT':'587',
            'SMTP_USERNAME':'smtp-user', 'SMTP_PASSWORD':'smtp-pass',
            'SMTP_FROM':'sender@example.com', 'SMTP_USE_SSL':'0'
        }, clear=False), patch.object(finance_app.smtplib, 'SMTP') as smtp_class:
            smtp = smtp_class.return_value.__enter__.return_value
            finance_app.send_email_otp('receiver@example.com', '123456', 'password_reset')
            smtp.starttls.assert_called_once()
            smtp.login.assert_called_once_with('smtp-user', 'smtp-pass')
            smtp.send_message.assert_called_once()

    def test_database_starts_without_old_transactions(self):
        self.assertEqual(sum(len(v) for v in self.records().values()),0)

if __name__ == '__main__': unittest.main()
