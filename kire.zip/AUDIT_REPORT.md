# Revision audit: multi-user accounts

- Added Signup with Full Name, Email, Phone Number, Password and Confirm Password.
- Added Email + Password login and account session handling.
- Passwords are stored using Werkzeug's salted password hashing.
- Added users table and per-user ownership for records and custom metadata.
- Settlement reads and writes are authorized through the owning parent record.
- Existing single-user records are migrated to the legacy `admin@localhost` account; they are not made visible to newly registered users.
- Added regression tests for signup, duplicate emails, password mismatch and cross-account data isolation.
- Added Gunicorn Procfile and persistent-disk deployment instructions for multi-device use.

Validation in the build environment:
- Python compilation: checked.
- JavaScript syntax: checked with Node.
- Full Flask API tests could not be executed in this environment because Flask is not installed and package-network access is unavailable. Run `python -m pip install -r requirements.txt` and `python -m unittest discover -s tests -v` on the deployment machine.
- Multi-device access is achieved only after deploying one shared server with a persistent database volume and HTTPS; the local development server alone is not accessible across the public internet.

## Master Admin and disposable-email protection update

- Added merged local disposable-domain cache sourced from multiple free community feeds (disposable-email-domains, 7c/fakefilter, FGRibreau/mailchecker and wesbos/burner-email-providers).
- Cache refresh is rate-limited to once per 24 hours; a failed remote refresh retains the last successful local cache and does not stop signup.
- Added conservative provider-specific MX fingerprint checks. Generic shared hosting/cloud MX providers are not blocked by fingerprint alone.
- Added Master Admin APIs and dashboard controls for custom domain allow/block/remove rules and manual database refresh.
- Updated the login identifier field to accept the built-in `admin` username as well as email addresses.
- SMTP remains fail-open for timeouts, policy rejections, greylisting and inconclusive results; only explicit permanent mailbox-not-found responses block. No verification email or SMTP DATA is sent.

Additional validation:
- Python compilation: checked after changes.
- JavaScript syntax: checked with Node after changes.
- ZIP archive integrity: checked.
- Full Flask API regression suite: not run in this environment because Flask and the project dependencies are not installed. Run the documented test command after installing requirements.


## Requested UX and email-verification revision (2026-11-15)

- Added animated Login/Signup form transitions, tab transitions, modal entrance, summary-card entrance and the existing new-record row highlight; reduced-motion preferences are respected.
- Added an authentication-pending screen state so the Login screen and dashboard remain hidden until `/api/auth/status` resolves, preventing the logged-in reload flash.
- Moved Search/Add controls above each non-Dashboard tab's summary and history. Added Search controls to Payables, Receivables and Cash & Banks; filtering affects displayed history rows only, not calculations or summary totals.
- Changed Master Admin OTP UI to the requested “If you are admin, Login here.” action. OTP request responses now use generic wording and never return the destination email address.
- Added signup OTP request/verification endpoints. Signup data is staged with a hashed password and hashed one-time code; a user row and authenticated session are created only after a valid code is submitted. Codes expire after five minutes and allow at most five attempts.
- Signup email checks reject invalid syntax, authoritative missing DNS/MX and known disposable domains. DNS/SMTP timeouts or inconclusive server responses remain fail-open; SMTP RCPT probing never sends a message.
- Existing ledger record, settlement, balance and dashboard calculation code was not intentionally changed. Search filters only the visible ledger rows.

Validation performed:
- `python -m py_compile app.py tests/test_app.py`: passed.
- `node --check static/js/app.js`: passed.
- SQLite source database integrity check: `PRAGMA integrity_check` returned `ok`.
- Full Flask API regression tests could not run in this build container because Flask and the declared dependencies are not installed and package-network access is unavailable. Run `python -m pip install -r requirements.txt` followed by `python -m unittest discover -s tests -v` on PythonAnywhere or another environment with package access.
- Signup and Master Admin email OTP delivery requires the SMTP environment variables already documented in `.env.example` to be configured on the hosting account.

## Master Admin user management and Signup API response hardening (2026-11-15)

- Added a read-only per-user finance viewer opened by clicking the user's name. It shows Dashboard-wide entries, Income, Expense, Receivables, Payables, Cash & Banks, and settlement history, with settlement-derived outstanding/status values calculated using the same principal-minus-settlements rule as the user records API.
- Added permanent user deletion for non-master-admin accounts. The operation deletes the user's records, linked settlements, custom metadata, pending signup OTP and admin OTP rows, deletes the user row, then runs SQLite VACUUM outside the transaction to compact the database file. Master Admin accounts and the currently logged-in Master Admin are protected.
- Added JSON API error responses for API 404/405/500 errors and a generic JSON failure response for unexpected signup-request exceptions. Signup client now checks the response content type and displays a readable server error instead of throwing `Unexpected token '<'` when an HTML error page is returned.
- Added regression tests for per-user finance detail access and permanent deletion, including settlement removal and SQLite integrity.
- Validation performed: Python syntax compilation passed; JavaScript syntax check passed; source SQLite integrity and ZIP integrity checked. Full Flask regression suite could not be run because Flask is not installed in this environment. Live SMTP delivery and browser testing remain deployment-side checks.
