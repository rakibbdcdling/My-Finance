"""Personal Finance Manager - Flask API with validated SQLite persistence."""
from __future__ import annotations

import os
import secrets
import hashlib
from email.message import EmailMessage
import sqlite3
import uuid
import csv
import io
import math
import time
from collections import defaultdict, deque
from contextlib import contextmanager
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request, session, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import re
import smtplib
import socket
import ssl
import json
import threading
import urllib.request
from email.utils import parseaddr

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(exist_ok=True)
DB_NAME = Path(os.environ.get("FINANCE_DB_PATH", str(BASE_DIR / "finance.db"))).expanduser()


def load_secret_key() -> str:
    configured = os.environ.get("FINANCE_SECRET_KEY")
    if configured:
        return configured
    key_file = INSTANCE_DIR / ".secret_key"
    if key_file.exists():
        return key_file.read_text(encoding="utf-8").strip()
    key = secrets.token_urlsafe(48)
    key_file.write_text(key, encoding="utf-8")
    try:
        key_file.chmod(0o600)
    except OSError:
        pass
    return key


app = Flask(__name__)
app.config.update(
    SECRET_KEY=load_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("FINANCE_COOKIE_SECURE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=60 * 60 * 12,
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,
)
ADMIN_USERNAME = os.environ.get("FINANCE_USERNAME", "admin")
MASTER_ADMIN_EMAIL = os.environ.get("MASTER_ADMIN_EMAIL", "rakib.bdcalling@gmail.com").strip().lower()

_LOGIN_ATTEMPTS: dict[str, deque[float]] = defaultdict(deque)

ALLOWED_TYPES = {"income", "expense", "payable", "receivable", "bankTxn"}
META_TYPES = {"source", "category", "name", "method"}
VALID_STATUSES = {"Paid", "Unpaid"}


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_NAME, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 15000")
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def init_db() -> None:
    with get_db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            phone TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            role TEXT NOT NULL DEFAULT 'user', status TEXT NOT NULL DEFAULT 'active'
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS admin_login_otps (
            email TEXT PRIMARY KEY COLLATE NOCASE, code_hash TEXT NOT NULL,
            expires_at INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS pending_signups (
            email TEXT PRIMARY KEY COLLATE NOCASE, full_name TEXT NOT NULL, phone TEXT NOT NULL,
            password_hash TEXT NOT NULL, code_hash TEXT NOT NULL, expires_at INTEGER NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS email_domain_rules (
            domain TEXT PRIMARY KEY COLLATE NOCASE, rule TEXT NOT NULL CHECK(rule IN ('allow','block')),
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_by TEXT
        )""")
        user_cols = {r['name'] for r in conn.execute("PRAGMA table_info(users)")}
        if 'role' not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")
        if 'status' not in user_cols:
            conn.execute("ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'")
        conn.execute("""CREATE TABLE IF NOT EXISTS records (
            id TEXT PRIMARY KEY, type TEXT NOT NULL, date TEXT NOT NULL,
            amount REAL NOT NULL CHECK(amount > 0), source TEXT, category TEXT,
            name TEXT, method TEXT NOT NULL, status TEXT, note TEXT, from_method TEXT,
            user_id TEXT REFERENCES users(id)
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS meta_options (
            category_type TEXT NOT NULL, val TEXT NOT NULL, user_id TEXT REFERENCES users(id),
            UNIQUE(user_id, category_type, val)
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_records_date ON records(date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_records_type ON records(type)")
        conn.execute("""CREATE TABLE IF NOT EXISTS settlements (
            id TEXT PRIMARY KEY, parent_id TEXT NOT NULL REFERENCES records(id),
            date TEXT NOT NULL, amount REAL NOT NULL CHECK(amount > 0),
            method TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_settlements_parent ON settlements(parent_id)")
        # Upgrade databases created by earlier single-user versions without losing their data.
        # Older releases had a global UNIQUE(category_type, val); rebuild it so each user
        # can maintain private custom dropdown values.
        meta_sql = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='meta_options'").fetchone()[0] or ''
        if 'UNIQUE(CATEGORY_TYPE,VAL)' in meta_sql.upper().replace(' ', ''):
            conn.execute("DROP INDEX IF EXISTS idx_meta_user")
            conn.execute("ALTER TABLE meta_options RENAME TO meta_options_legacy")
            conn.execute("CREATE TABLE meta_options (category_type TEXT NOT NULL, val TEXT NOT NULL, user_id TEXT REFERENCES users(id), UNIQUE(user_id, category_type, val))")
            old_cols = {r['name'] for r in conn.execute("PRAGMA table_info(meta_options_legacy)")}
            if 'user_id' in old_cols:
                conn.execute("INSERT OR IGNORE INTO meta_options(category_type,val,user_id) SELECT category_type,val,user_id FROM meta_options_legacy")
            else:
                conn.execute("INSERT OR IGNORE INTO meta_options(category_type,val,user_id) SELECT category_type,val,NULL FROM meta_options_legacy")
            conn.execute("DROP TABLE meta_options_legacy")
        for table in ('records', 'meta_options'):
            cols = {r['name'] for r in conn.execute(f"PRAGMA table_info({table})")}
            if 'user_id' not in cols:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN user_id TEXT REFERENCES users(id)")
        legacy = conn.execute("SELECT id FROM users WHERE email=?", ('admin@localhost',)).fetchone()
        if not legacy:
            legacy_id = 'usr_legacy_admin'
            conn.execute("INSERT INTO users(id,full_name,email,phone,password_hash) VALUES(?,?,?,?,?)",
                         (legacy_id, 'Finance Admin', 'admin@localhost', '', ''))
            conn.execute("UPDATE users SET role='master_admin', status='active' WHERE id=?", (legacy_id,))
        else:
            legacy_id = legacy['id']
            conn.execute("UPDATE users SET role='master_admin', status='active' WHERE id=?", (legacy_id,))
        conn.execute("UPDATE records SET user_id=? WHERE user_id IS NULL", (legacy_id,))
        conn.execute("UPDATE meta_options SET user_id=? WHERE user_id IS NULL", (legacy_id,))
        conn.execute("CREATE INDEX IF NOT EXISTS idx_records_user ON records(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_meta_user ON meta_options(user_id)")


init_db()

@app.errorhandler(404)
def api_not_found(error):
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'message': 'API endpoint not found.', 'error': 'Not Found'}), 404
    return error

@app.errorhandler(405)
def api_method_not_allowed(error):
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'message': 'Method not allowed for this API endpoint.', 'error': 'Method Not Allowed'}), 405
    return error

@app.errorhandler(500)
def api_internal_error(error):
    if request.path.startswith('/api/'):
        app.logger.exception('Unhandled API exception')
        return jsonify({'success': False, 'message': 'Internal server error. Please check the application logs.', 'error': 'Internal Server Error'}), 500
    return error


def json_body() -> dict[str, Any]:
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def clean_text(value: Any, field: str, *, required: bool = False, limit: int = 120) -> str | None:
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ValueError(f"{field} must be text")
    value = value.strip()
    if required and not value:
        raise ValueError(f"{field} is required")
    if len(value) > limit:
        raise ValueError(f"{field} is too long (maximum {limit} characters)")
    return value or None


def parse_amount(value: Any) -> float:
    if isinstance(value, bool):
        raise ValueError("Amount must be a valid number")
    try:
        amount = float(value)
    except (TypeError, ValueError):
        raise ValueError("Amount must be a valid number")
    if not (amount > 0 and amount < 1e15):
        raise ValueError("Amount must be greater than zero and within the supported limit")
    rounded = round(amount, 2)
    if rounded <= 0:
        raise ValueError("Amount must be at least 0.01")
    return rounded


def validate_date(value: Any) -> str:
    value = clean_text(value, "Date", required=True, limit=40)
    for fmt in ("%d %b, %Y %H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value, fmt).strftime("%d %b, %Y %H:%M:%S")
        except ValueError:
            continue
    raise ValueError("Date format is invalid")


def record_datetime(value: str) -> datetime:
    for fmt in ("%d %b, %Y %H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt)
        except (TypeError, ValueError):
            continue
    return datetime.min


def validate_record(data: dict[str, Any], record_type: str) -> dict[str, Any]:
    if not isinstance(record_type, str) or record_type not in ALLOWED_TYPES:
        raise ValueError("Unsupported record type")
    result: dict[str, Any] = {
        "date": validate_date(data.get("date")),
        "amount": parse_amount(data.get("amount")),
        "method": clean_text(data.get("method"), "Payment method", required=True),
        "source": None, "category": None, "name": None,
        "status": None, "note": None, "from_method": None,
    }
    if record_type == "income":
        result["source"] = clean_text(data.get("source"), "Source", required=True)
    elif record_type == "expense":
        result["category"] = clean_text(data.get("category"), "Category", required=True)
    elif record_type in {"payable", "receivable"}:
        result["name"] = clean_text(data.get("name"), "Name", required=True)
        status = data.get("status", "Unpaid")
        if not isinstance(status, str) or status not in VALID_STATUSES:
            raise ValueError("Status must be Paid or Unpaid")
        # New payable/receivable rows are principal entries. Their status is derived
        # from linked settlement rows and cannot be manually toggled.
        result["status"] = "Unpaid"
    elif record_type == "bankTxn":
        note = clean_text(data.get("note", "Deposit"), "Transaction note", required=True)
        if note != "Deposit" and not note.startswith("From "):
            raise ValueError("Transaction note must be Deposit or a valid transfer source")
        result["note"] = note
        if note.startswith("From "):
            note_source = clean_text(note[5:].strip(), "Transfer source", required=True)
            supplied_source = data.get("fromMethod")
            if supplied_source not in (None, "", note_source):
                raise ValueError("Transfer source does not match the transaction note")
            source_method = note_source
            if source_method == result["method"]:
                raise ValueError("Transfer source and destination must be different accounts")
            result["from_method"] = source_method
    return result


def current_user_id() -> str:
    user = session.get("user") or {}
    return str(user.get("id", ""))


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            return jsonify({"error": "Unauthorized. Please log in."}), 401
        return fn(*args, **kwargs)
    return wrapped


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response


@app.errorhandler(413)
def too_large(_error):
    return jsonify({"error": "Request body is too large"}), 413


@app.route("/")
def index():
    return render_template("index.html")


# Signup validation is deliberately fail-open for inconclusive network/SMTP results.
# Several maintained, free community blocklists are merged into a local cache.
# Network refresh is rate-limited and failures never erase the last known-good cache.
_DISPOSABLE_DOMAINS = {
    '10minutemail.com','10minutemail.net','guerrillamail.com','mailinator.com',
    'tempmail.com','temp-mail.org','yopmail.com','yopmail.fr','getnada.com',
    'maildrop.cc','dispostable.com','fakeinbox.com','trashmail.com','sharklasers.com',
    'guerrillamailblock.com','grr.la','throwawaymail.com','mohmal.com',
    'minuteinbox.com','emailondeck.com','inboxkitten.com','mailnesia.com',
    'tempr.email','discard.email','mailcatch.com','mintemail.com',
}
_DISPOSABLE_DOMAINS.update(x.strip().lower() for x in os.environ.get('DISPOSABLE_EMAIL_DOMAINS','').split(',') if x.strip())
_DISPOSABLE_SOURCES = (
    'https://raw.githubusercontent.com/disposable-email-domains/disposable-email-domains/main/disposable_email_blocklist.conf',
    'https://raw.githubusercontent.com/7c/fakefilter/main/txt/data.txt',
    'https://raw.githubusercontent.com/FGRibreau/mailchecker/master/list.txt',
    'https://raw.githubusercontent.com/wesbos/burner-email-providers/master/emails.txt',
)
_DISPOSABLE_CACHE = INSTANCE_DIR / 'disposable_domains.json'
_DISPOSABLE_REFRESH_LOCK = threading.Lock()
_DISPOSABLE_LAST_REFRESH_ATTEMPT = 0.0
_DISPOSABLE_REFRESH_INTERVAL = 24 * 60 * 60
# Only provider-specific MX fingerprints are used; generic cloud/mail hosts are not blocked.
_DISPOSABLE_MX_SUFFIXES = (
    'mailinator.com','yopmail.com','guerrillamail.com','sharklasers.com',
    'maildrop.cc','mohmal.com','getnada.com','tempmail.com','temp-mail.org',
    '10minutemail.com','emailondeck.com','inboxkitten.com','mailnesia.com',
)

def _domain_matches(domain: str, entries: set[str]) -> bool:
    domain = domain.lower().strip('. ')
    return any(domain == item or domain.endswith('.' + item) for item in entries)

def _load_disposable_cache() -> set[str]:
    try:
        data = json.loads(_DISPOSABLE_CACHE.read_text(encoding='utf-8'))
        domains = data.get('domains', []) if isinstance(data, dict) else []
        return {str(x).strip().lower().lstrip('@').rstrip('.') for x in domains if isinstance(x, str) and '.' in x}
    except (OSError, ValueError, TypeError):
        return set()

def refresh_disposable_domains(force: bool = False) -> dict[str, Any]:
    """Merge free community lists; keep old cache if feeds are unavailable."""
    global _DISPOSABLE_LAST_REFRESH_ATTEMPT
    now = time.time()
    cached = _load_disposable_cache()
    try:
        cache_data = json.loads(_DISPOSABLE_CACHE.read_text(encoding='utf-8'))
        last_success = float(cache_data.get('updated_at_epoch', 0))
    except (OSError, ValueError, TypeError):
        last_success = 0.0
    if not force and (now - last_success < _DISPOSABLE_REFRESH_INTERVAL):
        return {'domains': len(cached | _DISPOSABLE_DOMAINS), 'updated': False, 'last_updated': cache_data.get('updated_at') if 'cache_data' in locals() and isinstance(cache_data, dict) else None}
    if not _DISPOSABLE_REFRESH_LOCK.acquire(blocking=False):
        return {'domains': len(cached | _DISPOSABLE_DOMAINS), 'updated': False, 'refreshing': True}
    try:
        if not force and now - _DISPOSABLE_LAST_REFRESH_ATTEMPT < 60:
            return {'domains': len(cached | _DISPOSABLE_DOMAINS), 'updated': False}
        _DISPOSABLE_LAST_REFRESH_ATTEMPT = now
        merged = set(cached)
        successes = 0
        for url in _DISPOSABLE_SOURCES:
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'FinanceApp-DisposableDomainSync/1.0'})
                with urllib.request.urlopen(req, timeout=2.0) as response:
                    raw = response.read(8 * 1024 * 1024).decode('utf-8', 'ignore')
                found = {line.strip().lower().lstrip('@').rstrip('.') for line in raw.splitlines()
                         if line.strip() and not line.lstrip().startswith(('#','//')) and '.' in line.strip() and ' ' not in line.strip()}
                if len(found) >= 100:
                    merged.update(found); successes += 1
            except Exception:
                continue
        if successes:
            payload = {'updated_at': datetime.utcnow().isoformat(timespec='seconds') + 'Z',
                       'updated_at_epoch': now, 'sources_succeeded': successes, 'domains': sorted(merged)}
            tmp = _DISPOSABLE_CACHE.with_suffix('.tmp')
            tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
            tmp.replace(_DISPOSABLE_CACHE)
            return {'domains': len(merged | _DISPOSABLE_DOMAINS), 'updated': True, 'sources_succeeded': successes, 'last_updated': payload['updated_at']}
        return {'domains': len(cached | _DISPOSABLE_DOMAINS), 'updated': False, 'sources_succeeded': 0, 'warning': 'All remote feeds unavailable; retained local cache'}
    finally:
        _DISPOSABLE_REFRESH_LOCK.release()

def _custom_domain_rule(domain: str) -> str | None:
    with get_db() as conn:
        rows = conn.execute('SELECT domain,rule FROM email_domain_rules').fetchall()
    matches = [(len(row['domain']), row['rule']) for row in rows
               if domain == row['domain'].lower() or domain.endswith('.' + row['domain'].lower())]
    return max(matches, default=(0, None), key=lambda item: item[0])[1]

def validate_signup_email(address: str) -> tuple[bool, str, str]:
    """Return (allowed, classification, user_message). Never sends an email."""
    from email_validator import validate_email, EmailNotValidError
    try:
        parsed = validate_email(address, check_deliverability=False, allow_smtputf8=False)
        normalized = parsed.normalized
        domain = parsed.domain.lower().rstrip('.')
    except EmailNotValidError:
        return False, 'invalid_syntax', 'সঠিক Email Address দিন।'

    # Refresh the local cache at most once per 24h; signup still works if feeds are down.
    refresh_disposable_domains()
    rule = _custom_domain_rule(domain)
    if rule == 'block':
        return False, 'custom_blocked', 'এই Email Domain Admin Blocklist-এ রয়েছে।'
    if rule != 'allow':
        disposable_domains = _DISPOSABLE_DOMAINS | _load_disposable_cache()
        if _domain_matches(domain, disposable_domains):
            return False, 'disposable', 'Disposable/temporary Email দিয়ে Account খোলা যাবে না।'

    # DNS: NXDOMAIN / authoritative no-mail domain is a definite failure.
    # Temporary resolver failures are inconclusive and therefore allowed.
    try:
        import dns.resolver
        resolver = dns.resolver.Resolver(); resolver.lifetime = 4.0; resolver.timeout = 2.0
        mx_records = []
        try:
            answers = resolver.resolve(domain, 'MX')
            mx_records = sorted(answers, key=lambda r: r.preference)
        except dns.resolver.NoAnswer:
            return False, 'no_mx_record', 'এই Email Domain-এ কোনো MX Record পাওয়া যায়নি।'
        except dns.resolver.NXDOMAIN:
            return False, 'invalid_dns', 'এই Email Domain-এর DNS পাওয়া যায়নি।'
        except (dns.resolver.Timeout, dns.resolver.NoNameservers):
            return True, 'unknown_dns', ''

        if not mx_records:
            return False, 'no_mx_record', 'এই Email Domain-এ কোনো MX Record পাওয়া যায়নি।'
        else:
            mx_hosts = [str(r.exchange).rstrip('.').lower() for r in mx_records if str(r.exchange).rstrip('.')]
            if not mx_hosts:
                return False, 'no_mail_route', 'এই Email Domain-এ কোনো valid Mail Server নেই।'
    except ImportError:
        return True, 'unknown_dns', ''
    except Exception:
        # Resolver/library failures that are not authoritative DNS negatives are inconclusive.
        app.logger.warning('Email DNS screening was inconclusive; allowing signup to continue', exc_info=True)
        return True, 'unknown_dns', ''

    # MX fingerprint: block only explicit disposable-provider infrastructure.
    if rule != 'allow':
        for mx_host in mx_hosts:
            if _domain_matches(mx_host, set(_DISPOSABLE_MX_SUFFIXES)):
                return False, 'disposable_mx_fingerprint', 'এই Email Domain পরিচিত Temporary Mail Server ব্যবহার করছে।'

    # SMTP RCPT probing only. No DATA command is ever issued and no message is sent.
    probe_sender = f"validator@{os.environ.get('SMTP_PROBE_SENDER_DOMAIN', domain)}"
    for host in mx_hosts[:3]:
        try:
            with smtplib.SMTP(host, 25, timeout=5) as smtp:
                code, _ = smtp.ehlo()
                if code >= 400: continue
                try:
                    if smtp.has_extn('starttls'):
                        smtp.starttls(context=ssl.create_default_context()); smtp.ehlo()
                except (smtplib.SMTPException, ssl.SSLError, OSError):
                    pass
                try:
                    mail_code, _ = smtp.mail(probe_sender)
                    if mail_code >= 500: continue
                    rcpt_code, rcpt_msg = smtp.rcpt(normalized)
                except (smtplib.SMTPException, OSError):
                    continue
                msg = rcpt_msg.decode('utf-8', 'ignore').lower() if isinstance(rcpt_msg, bytes) else str(rcpt_msg).lower()
                definite_invalid = rcpt_code in (550, 551, 553) and any(token in msg for token in (
                    '5.1.1','5.1.0','user unknown','unknown user','no such user','mailbox not found',
                    'recipient does not exist','invalid recipient','account does not exist'
                ))
                if definite_invalid:
                    return False, 'smtp_invalid', 'এই Email Address-এর Mailbox সার্ভার নিশ্চিতভাবে Invalid বলেছে।'
                if rcpt_code in (250, 251, 252): return True, 'valid', ''
                return True, 'unknown_smtp', ''
        except (OSError, smtplib.SMTPException, socket.timeout):
            continue
        except Exception:
            # Any unexpected SMTP/probe failure is inconclusive, not a signup rejection.
            continue
    return True, 'unknown_smtp', ''


_SIGNUP_OTP_REQUESTS: dict[str, deque[float]] = defaultdict(deque)


def send_email_otp(recipient: str, code: str, purpose: str = 'signup') -> None:
    """Send a one-time code using the configured hosting SMTP account."""
    host = os.environ.get('SMTP_HOST', '').strip()
    username = os.environ.get('SMTP_USERNAME', '').strip()
    password = os.environ.get('SMTP_PASSWORD', '')
    sender = os.environ.get('SMTP_FROM', username).strip()
    if not all((host, username, password, sender)):
        raise RuntimeError('Email OTP settings are not configured.')
    is_admin = purpose == 'admin'
    msg = EmailMessage()
    msg['Subject'] = 'Your Master Admin Login Code' if is_admin else 'Verify your My Finance account'
    msg['From'] = sender
    msg['To'] = recipient
    account_label = 'Master Admin login' if is_admin else 'My Finance account verification'
    msg.set_content(
        f'Your {account_label} code is: {code}\n\n'
        'This code expires in 5 minutes. If you did not request it, ignore this email.'
    )
    port = int(os.environ.get('SMTP_PORT', '587'))
    if os.environ.get('SMTP_USE_SSL', '0') == '1':
        with smtplib.SMTP_SSL(host, port, timeout=15, context=ssl.create_default_context()) as smtp:
            smtp.login(username, password)
            smtp.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=15) as smtp:
            smtp.ehlo()
            smtp.starttls(context=ssl.create_default_context())
            smtp.ehlo()
            smtp.login(username, password)
            smtp.send_message(msg)


@app.route("/api/auth/signup/request-code", methods=["POST"])
def signup_request_code():
    data = json_body()
    try:
        full_name = clean_text(data.get('fullName'), 'Full name', required=True, limit=120)
        email = clean_text(data.get('email'), 'Email', required=True, limit=254).lower()
        phone = clean_text(data.get('phone'), 'Phone number', required=True, limit=30)
        password = data.get('password')
        confirm = data.get('confirmPassword')
        allowed, email_status, email_message = validate_signup_email(email)
        if not allowed:
            raise ValueError(email_message)
        if not isinstance(password, str) or len(password) < 8:
            raise ValueError('Password কমপক্ষে ৮ অক্ষরের হতে হবে।')
        if password != confirm:
            raise ValueError('Password এবং Confirm Password মিলছে না।')
        with get_db() as conn:
            exists = conn.execute('SELECT 1 FROM users WHERE email=? COLLATE NOCASE', (email,)).fetchone()
        if exists:
            return jsonify({'success': False, 'message': 'এই Email দিয়ে ইতিমধ্যে Account খোলা হয়েছে।'}), 409

        ip = request.remote_addr or 'unknown'
        now = int(time.time())
        bucket = _SIGNUP_OTP_REQUESTS[ip]
        while bucket and now - bucket[0] > 900:
            bucket.popleft()
        if len(bucket) >= 5:
            return jsonify({'success': False, 'message': 'অনেকবার Verification Code চাওয়া হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন।'}), 429

        code = f'{secrets.randbelow(1_000_000):06d}'
        try:
            send_email_otp(email, code, 'signup')
        except Exception:
            app.logger.exception('Unable to send signup verification code')
            return jsonify({'success': False, 'message': 'Verification email পাঠানো যায়নি। Email/SMTP settings পরীক্ষা করে আবার চেষ্টা করুন।'}), 503

        with get_db() as conn:
            conn.execute("""INSERT INTO pending_signups
                (email,full_name,phone,password_hash,code_hash,expires_at,attempts,created_at)
                VALUES(?,?,?,?,?,?,0,?)
                ON CONFLICT(email) DO UPDATE SET full_name=excluded.full_name,phone=excluded.phone,
                password_hash=excluded.password_hash,code_hash=excluded.code_hash,
                expires_at=excluded.expires_at,attempts=0,created_at=excluded.created_at""",
                (email, full_name, phone, generate_password_hash(password),
                 hashlib.sha256(code.encode()).hexdigest(), now + 300, now))
        bucket.append(now)
        return jsonify({'success': True, 'message': 'Please check your email. We sent a verification code.'})
    except ValueError as exc:
        return jsonify({'success': False, 'message': str(exc)}), 400
    except Exception:
        app.logger.exception('Unexpected signup request failure')
        return jsonify({'success': False, 'message': 'Signup request could not be completed. Please try again or contact the administrator.'}), 500


@app.route("/api/auth/signup/verify-code", methods=["POST"])
def signup_verify_code():
    data = json_body()
    email = data.get('email', '')
    code = data.get('code', '')
    if not isinstance(email, str) or not isinstance(code, str) or not re.fullmatch(r'\d{6}', code):
        return jsonify({'success': False, 'message': 'সঠিক Email এবং ৬ ডিজিটের Verification Code দিন।'}), 400
    email = email.strip().lower()
    now = int(time.time())
    with get_db() as conn:
        pending = conn.execute('SELECT * FROM pending_signups WHERE email=? COLLATE NOCASE', (email,)).fetchone()
        if not pending or pending['expires_at'] < now or pending['attempts'] >= 5:
            conn.execute('DELETE FROM pending_signups WHERE email=? COLLATE NOCASE', (email,))
            return jsonify({'success': False, 'message': 'Code-এর মেয়াদ শেষ অথবা Code পাওয়া যায়নি। নতুন Code নিন।'}), 401
        if not secrets.compare_digest(pending['code_hash'], hashlib.sha256(code.encode()).hexdigest()):
            conn.execute('UPDATE pending_signups SET attempts=attempts+1 WHERE email=? COLLATE NOCASE', (email,))
            return jsonify({'success': False, 'message': 'ভুল Verification Code।'}), 401
        user_id = 'usr_' + uuid.uuid4().hex
        try:
            conn.execute('INSERT INTO users(id,full_name,email,phone,password_hash) VALUES(?,?,?,?,?)',
                         (user_id, pending['full_name'], pending['email'], pending['phone'], pending['password_hash']))
        except sqlite3.IntegrityError:
            conn.execute('DELETE FROM pending_signups WHERE email=? COLLATE NOCASE', (email,))
            return jsonify({'success': False, 'message': 'এই Email দিয়ে ইতিমধ্যে Account খোলা হয়েছে।'}), 409
        conn.execute('DELETE FROM pending_signups WHERE email=? COLLATE NOCASE', (email,))
        user = {'id': user_id, 'username': pending['email'], 'name': pending['full_name'],
                'email': pending['email'], 'phone': pending['phone'], 'role': 'user'}
    session.clear()
    session.permanent = True
    session['user'] = user
    return jsonify({'success': True, 'user': user}), 201


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = json_body()
    email = data.get('email', data.get('username', ''))
    password = data.get('password', '')
    if not isinstance(email, str) or not isinstance(password, str):
        return jsonify({'success': False, 'message': 'ভুল Email অথবা Password।'}), 401
    ip = request.remote_addr or 'unknown'
    attempts = _LOGIN_ATTEMPTS[ip]
    now = time.time()
    while attempts and now - attempts[0] > 900: attempts.popleft()
    if len(attempts) >= 8:
        return jsonify({'success': False, 'message': 'অনেকবার ভুল চেষ্টা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন।'}), 429
    with get_db() as conn:
        # Keep compatibility with the previous local admin login during migration.
        lookup = 'admin@localhost' if email.strip() == ADMIN_USERNAME else email.strip().lower()
        row = conn.execute('SELECT * FROM users WHERE email=? COLLATE NOCASE', (lookup,)).fetchone()
    if row and row['role'] == 'master_admin':
        return jsonify({'success': False, 'message': 'Master Admin-এর জন্য Email OTP ব্যবহার করুন।'}), 401
    if not row or not row['password_hash'] or not check_password_hash(row['password_hash'], password):
        attempts.append(now)
        return jsonify({'success': False, 'message': 'ভুল Email অথবা Password।'}), 401
    if row['status'] != 'active':
        return jsonify({'success': False, 'message': 'এই Account বর্তমানে Suspended। সহায়তার জন্য Master Admin-এর সঙ্গে যোগাযোগ করুন: rakib.bdcalling@gmail.com'}), 403
    attempts.clear(); session.clear(); session.permanent = True
    user = {'id': row['id'], 'username': row['email'], 'name': row['full_name'], 'email': row['email'], 'phone': row['phone'], 'role': row['role']}
    session['user'] = user
    return jsonify({'success': True, 'user': user})



_OTP_REQUESTS: dict[str, deque[float]] = defaultdict(deque)

def send_master_admin_otp(code: str) -> None:
    send_email_otp(MASTER_ADMIN_EMAIL, code, 'admin')


@app.route('/api/master-admin/request-code', methods=['POST'])
def master_admin_request_code():
    # The destination is resolved only on the server; never echo it to the browser.
    data = json_body()
    ip = request.remote_addr or 'unknown'; now = int(time.time())
    bucket = _OTP_REQUESTS[ip]
    while bucket and now - bucket[0] > 900: bucket.popleft()
    if len(bucket) >= 4:
        return jsonify({'success': False, 'message': 'অনেকবার Code চাওয়া হয়েছে। ১৫ মিনিট পরে চেষ্টা করুন।'}), 429
    with get_db() as conn:
        admin = conn.execute("SELECT id FROM users WHERE role='master_admin' AND status='active' ORDER BY created_at LIMIT 1").fetchone()
    if not admin:
        return jsonify({'success': False, 'message': 'Active Master Admin পাওয়া যায়নি।'}), 404
    code = f'{secrets.randbelow(1_000_000):06d}'
    try:
        send_master_admin_otp(code)
    except Exception:
        app.logger.exception('Unable to send Master Admin OTP')
        return jsonify({'success': False, 'message': 'Email পাঠানো যায়নি। Hosting-এর SMTP settings পরীক্ষা করুন।'}), 503
    with get_db() as conn:
        conn.execute('INSERT INTO admin_login_otps(email,code_hash,expires_at,attempts,created_at) VALUES(?,?,?,?,?) ON CONFLICT(email) DO UPDATE SET code_hash=excluded.code_hash,expires_at=excluded.expires_at,attempts=0,created_at=excluded.created_at',
                     (MASTER_ADMIN_EMAIL, hashlib.sha256(code.encode()).hexdigest(), now + 300, 0, now))
    bucket.append(now)
    return jsonify({'success': True, 'message': 'Please check your admin email. We sent a login code.'})


@app.route('/api/master-admin/verify-code', methods=['POST'])
def master_admin_verify_code():
    data = json_body(); code = data.get('code', '')
    if not isinstance(code, str) or not re.fullmatch(r'\d{6}', code):
        return jsonify({'success': False, 'message': '৬ ডিজিটের Code দিন।'}), 400
    now = int(time.time())
    with get_db() as conn:
        otp = conn.execute('SELECT * FROM admin_login_otps WHERE email=?', (MASTER_ADMIN_EMAIL,)).fetchone()
        if not otp or otp['expires_at'] < now or otp['attempts'] >= 5:
            conn.execute('DELETE FROM admin_login_otps WHERE email=?', (MASTER_ADMIN_EMAIL,))
            return jsonify({'success': False, 'message': 'Code-এর মেয়াদ শেষ অথবা Code পাওয়া যায়নি। নতুন Code নিন।'}), 401
        if not secrets.compare_digest(otp['code_hash'], hashlib.sha256(code.encode()).hexdigest()):
            conn.execute('UPDATE admin_login_otps SET attempts=attempts+1 WHERE email=?', (MASTER_ADMIN_EMAIL,))
            return jsonify({'success': False, 'message': 'ভুল Verification Code।'}), 401
        conn.execute('DELETE FROM admin_login_otps WHERE email=?', (MASTER_ADMIN_EMAIL,))
        admin = conn.execute("SELECT * FROM users WHERE role='master_admin' AND status='active' ORDER BY created_at LIMIT 1").fetchone()
    if not admin:
        return jsonify({'success': False, 'message': 'Active Master Admin পাওয়া যায়নি।'}), 403
    session.clear(); session.permanent = True
    user = {'id': admin['id'], 'username': admin['email'], 'name': admin['full_name'], 'email': admin['email'], 'phone': admin['phone'], 'role': admin['role']}
    session['user'] = user
    return jsonify({'success': True, 'user': user})

def master_admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapped(*args, **kwargs):
        if (session.get('user') or {}).get('role') != 'master_admin':
            return jsonify({'error': 'Master Admin access required.'}), 403
        return fn(*args, **kwargs)
    return wrapped


@app.route('/api/master-admin/overview', methods=['GET'])
@master_admin_required
def master_admin_overview():
    with get_db() as conn:
        users = conn.execute("SELECT id,full_name,email,phone,created_at,role,status FROM users ORDER BY created_at DESC").fetchall()
        totals = conn.execute("SELECT COUNT(*) AS records, COALESCE(SUM(amount),0) AS total_amount FROM records").fetchone()
        records = conn.execute("SELECT r.*,u.email AS owner_email FROM records r LEFT JOIN users u ON u.id=r.user_id ORDER BY r.date DESC").fetchall()
    return jsonify({'users':[dict(x) for x in users], 'financial_access':'full',
                    'account_deletion_policy':'suspend', 'totals':dict(totals),
                    'financial_records':[dict(x) for x in records]})


@app.route('/api/master-admin/email-protection', methods=['GET'])
@master_admin_required
def master_admin_email_protection():
    cache = _load_disposable_cache()
    try:
        cache_info = json.loads(_DISPOSABLE_CACHE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        cache_info = {}
    with get_db() as conn:
        rules = [dict(row) for row in conn.execute('SELECT domain,rule,updated_at FROM email_domain_rules ORDER BY domain').fetchall()]
    return jsonify({'known_disposable_domains': len(cache | _DISPOSABLE_DOMAINS),
                    'custom_rules': rules, 'last_updated': cache_info.get('updated_at'),
                    'sources_succeeded': cache_info.get('sources_succeeded', 0),
                    'refresh_interval_hours': 24})


@app.route('/api/master-admin/email-protection/refresh', methods=['POST'])
@master_admin_required
def master_admin_refresh_email_domains():
    result = refresh_disposable_domains(force=True)
    return jsonify({'success': bool(result.get('updated')), **result})


@app.route('/api/master-admin/email-protection/rules', methods=['POST'])
@master_admin_required
def master_admin_email_domain_rule():
    data = json_body()
    domain = data.get('domain', '')
    action = data.get('action', '')
    if not isinstance(domain, str):
        return jsonify({'success':False,'message':'Domain must be text.'}),400
    domain = domain.strip().lower().rstrip('.')
    if len(domain) > 253 or not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}', domain):
        return jsonify({'success':False,'message':'সঠিক Domain দিন (যেমন example.com)।'}),400
    if action not in ('allow','block','remove'):
        return jsonify({'success':False,'message':'Action allow, block অথবা remove হতে হবে।'}),400
    with get_db() as conn:
        if action == 'remove':
            conn.execute('DELETE FROM email_domain_rules WHERE domain=? COLLATE NOCASE',(domain,))
        else:
            conn.execute('INSERT INTO email_domain_rules(domain,rule,updated_by) VALUES(?,?,?) ON CONFLICT(domain) DO UPDATE SET rule=excluded.rule,updated_at=CURRENT_TIMESTAMP,updated_by=excluded.updated_by',
                         (domain,action,current_user_id()))
    return jsonify({'success':True,'domain':domain,'action':action})


@app.route('/api/master-admin/users/<user_id>/suspend', methods=['POST'])
@master_admin_required
def master_admin_suspend_user(user_id):
    if user_id == current_user_id():
        return jsonify({'success':False,'message':'নিজের Master Admin Account suspend করা যাবে না।'}), 400
    with get_db() as conn:
        row=conn.execute('SELECT id FROM users WHERE id=?',(user_id,)).fetchone()
        if not row: return jsonify({'success':False,'message':'User পাওয়া যায়নি।'}),404
        conn.execute("UPDATE users SET status='suspended' WHERE id=? AND role!='master_admin'",(user_id,))
    return jsonify({'success':True,'account_deletion_policy':'suspend'})


@app.route('/api/master-admin/users/<user_id>/data', methods=['GET'])
@master_admin_required
def master_admin_user_data(user_id):
    """Read-only full ledger view for one account; never changes finance calculations."""
    with get_db() as conn:
        user = conn.execute("SELECT id,full_name,email,phone,created_at,role,status FROM users WHERE id=?", (user_id,)).fetchone()
        if not user:
            return jsonify({'success': False, 'message': 'User পাওয়া যায়নি।'}), 404
        records = conn.execute("SELECT * FROM records WHERE user_id=? ORDER BY date DESC", (user_id,)).fetchall()
        settlements = [dict(row) for row in conn.execute(
            "SELECT s.*, r.type AS record_type, r.name AS record_name FROM settlements s JOIN records r ON r.id=s.parent_id WHERE r.user_id=? ORDER BY s.date DESC, s.created_at DESC, s.id DESC",
            (user_id,)).fetchall()]
        meta = [dict(row) for row in conn.execute("SELECT category_type,val FROM meta_options WHERE user_id=? ORDER BY category_type,val", (user_id,)).fetchall()]
    settled = defaultdict(float)
    settlement_by_parent = defaultdict(list)
    for item in settlements:
        settled[item['parent_id']] += float(item['amount'])
        settlement_by_parent[item['parent_id']].append({'id': item['id'], 'date': item['date'], 'amount': float(item['amount']), 'method': item['method']})
    output_records = []
    for row in records:
        item = dict(row)
        if item['type'] in {'payable', 'receivable'}:
            item['settlements'] = settlement_by_parent.get(item['id'], [])
            item['settled'] = round(settled[item['id']], 2)
            item['outstanding'] = round(max(0, float(item['amount']) - settled[item['id']]), 2)
            item['status'] = 'Paid' if item['outstanding'] <= 0.001 else 'Unpaid'
        output_records.append(item)
    return jsonify({'success': True, 'user': dict(user), 'records': output_records,
                    'settlements': settlements, 'meta_options': meta})


@app.route('/api/master-admin/users/<user_id>', methods=['DELETE'])
@master_admin_required
def master_admin_delete_user(user_id):
    """Permanently remove a user and all owned rows, then compact SQLite storage."""
    if user_id == current_user_id():
        return jsonify({'success': False, 'message': 'নিজের Master Admin Account delete করা যাবে না।'}), 400
    try:
        with get_db() as conn:
            user = conn.execute("SELECT id,role FROM users WHERE id=?", (user_id,)).fetchone()
            if not user:
                return jsonify({'success': False, 'message': 'User পাওয়া যায়নি।'}), 404
            if user['role'] == 'master_admin':
                return jsonify({'success': False, 'message': 'অন্য Master Admin Account delete করা যাবে না।'}), 403
            conn.execute("DELETE FROM settlements WHERE parent_id IN (SELECT id FROM records WHERE user_id=?)", (user_id,))
            conn.execute("DELETE FROM records WHERE user_id=?", (user_id,))
            conn.execute("DELETE FROM meta_options WHERE user_id=?", (user_id,))
            conn.execute("DELETE FROM pending_signups WHERE email=(SELECT email FROM users WHERE id=?)", (user_id,))
            conn.execute("DELETE FROM admin_login_otps WHERE email=(SELECT email FROM users WHERE id=?)", (user_id,))
            conn.execute("DELETE FROM users WHERE id=?", (user_id,))
        # VACUUM must run outside a transaction; it rebuilds the DB file and releases free pages.
        with sqlite3.connect(DB_NAME, timeout=30) as compact_conn:
            compact_conn.execute('PRAGMA busy_timeout=30000')
            compact_conn.execute('VACUUM')
        return jsonify({'success': True, 'deleted': True, 'database_compacted': True,
                        'message': 'User account and all associated finance data permanently deleted.'})
    except sqlite3.Error:
        app.logger.exception('Permanent user deletion failed')
        return jsonify({'success': False, 'message': 'Database deletion failed. No success was reported; check server logs.'}), 500


@app.route('/api/master-admin/users/<user_id>/activate', methods=['POST'])
@master_admin_required
def master_admin_activate_user(user_id):
    with get_db() as conn:
        cur=conn.execute("UPDATE users SET status='active' WHERE id=? AND role!='master_admin'",(user_id,))
        if not cur.rowcount: return jsonify({'success':False,'message':'User পাওয়া যায়নি বা পরিবর্তনযোগ্য নয়।'}),404
    return jsonify({'success':True})


@app.route("/api/auth/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"success": True})


@app.route("/api/auth/status")
def auth_status():
    user = session.get("user")
    return jsonify({"authenticated": bool(user), **({"user": user} if user else {})})


@app.route("/api/meta", methods=["GET", "POST"])
@login_required
def handle_meta():
    if request.method == "POST":
        data = json_body()
        cat_type = data.get("type")
        try:
            if not isinstance(cat_type, str) or cat_type not in META_TYPES:
                raise ValueError("Unsupported option type")
            val = clean_text(data.get("value"), "Option", required=True)
            with get_db() as conn:
                conn.execute("INSERT OR IGNORE INTO meta_options (category_type, val, user_id) VALUES (?, ?, ?)", (cat_type, val, current_user_id()))
            return jsonify({"success": True})
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400
    meta = {"sources": [], "categories": [], "names": [], "methods": []}
    with get_db() as conn:
        rows = conn.execute("SELECT category_type, val FROM meta_options WHERE user_id=? ORDER BY val COLLATE NOCASE", (current_user_id(),)).fetchall()
    keys = {"source": "sources", "category": "categories", "name": "names", "method": "methods"}
    for row in rows:
        meta[keys[row["category_type"]]].append(row["val"])
    return jsonify(meta)


@app.route("/api/records", methods=["GET"])
@login_required
def get_records():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM records WHERE user_id=?", (current_user_id(),)).fetchall()
        settlements = conn.execute("SELECT s.* FROM settlements s JOIN records r ON r.id=s.parent_id WHERE r.user_id=? ORDER BY s.date, s.created_at, s.id", (current_user_id(),)).fetchall()
    by_parent: dict[str, list[dict[str, Any]]] = defaultdict(list)
    settled: dict[str, float] = defaultdict(float)
    for st in settlements:
        item = {"id": st["id"], "date": st["date"], "amount": float(st["amount"]), "method": st["method"]}
        by_parent[st["parent_id"]].append(item)
        settled[st["parent_id"]] += float(st["amount"])
    rows = sorted(rows, key=lambda row: (record_datetime(row["date"]), row["id"]), reverse=True)
    records = {"incomes": [], "expenses": [], "payables": [], "receivables": [], "bankTxns": []}
    key_map = {"income": "incomes", "expense": "expenses", "payable": "payables", "receivable": "receivables", "bankTxn": "bankTxns"}
    for row in rows:
        item = {"id": row["id"], "date": row["date"], "amount": float(row["amount"]), "method": row["method"]}
        kind = row["type"]
        if kind == "income": item["source"] = row["source"]
        elif kind == "expense": item["category"] = row["category"]
        elif kind in {"payable", "receivable"}:
            item["name"] = row["name"]
            item["settlements"] = by_parent.get(row["id"], [])
            item["settled"] = round(settled[row["id"]], 2)
            item["outstanding"] = round(max(0, float(row["amount"]) - settled[row["id"]]), 2)
            item["status"] = "Paid" if item["outstanding"] <= 0.001 else "Unpaid"
        elif kind == "bankTxn":
            item["note"], item["fromMethod"] = row["note"], row["from_method"]
        records[key_map[kind]].append(item)
    return jsonify(records)


@app.route("/api/records", methods=["POST"])
@login_required
def create_record():
    data = json_body()
    try:
        kind = data.get("type")
        values = validate_record(data, kind)
        record_id = "rec_" + uuid.uuid4().hex
        with get_db() as conn:
            conn.execute("""INSERT INTO records
                (id, type, date, amount, source, category, name, method, status, note, from_method, user_id)
                VALUES (:id, :type, :date, :amount, :source, :category, :name, :method, :status, :note, :from_method, :user_id)""",
                {"id": record_id, "type": kind, "user_id": current_user_id(), **values})
        return jsonify({"success": True, "id": record_id}), 201
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except sqlite3.Error:
        app.logger.exception("Database error creating record")
        return jsonify({"error": "Database operation failed"}), 500


@app.route("/api/records/<rec_id>", methods=["DELETE"])
@login_required
def delete_record(rec_id):
    """Permanently delete a ledger entry and its settlements, then compact SQLite."""
    try:
        with get_db() as conn:
            existing = conn.execute("SELECT id FROM records WHERE id = ? AND user_id=?", (rec_id, current_user_id())).fetchone()
            if not existing:
                return jsonify({"error": "Record not found"}), 404
            # Explicit child deletion works with databases created before FK cascade support.
            conn.execute("DELETE FROM settlements WHERE parent_id = ?", (rec_id,))
            conn.execute("DELETE FROM records WHERE id = ?", (rec_id,))
        # VACUUM reclaims deleted pages and physically shrinks the database file.
        # It must run outside the transaction/connection context above.
        vacuum_conn = sqlite3.connect(DB_NAME, timeout=30)
        try:
            vacuum_conn.execute("PRAGMA busy_timeout = 30000")
            vacuum_conn.execute("VACUUM")
        finally:
            vacuum_conn.close()
        return jsonify({"success": True, "id": rec_id, "database_compacted": True})
    except sqlite3.Error:
        app.logger.exception("Database error deleting record or compacting database")
        return jsonify({"error": "Record deletion or database compaction failed"}), 500


@app.route("/api/records/<rec_id>", methods=["PUT"])
@login_required
def update_record(rec_id):
    data = json_body()
    try:
        with get_db() as conn:
            existing = conn.execute("SELECT type FROM records WHERE id = ? AND user_id=?", (rec_id, current_user_id())).fetchone()
            if not existing:
                return jsonify({"error": "Record not found"}), 404
            kind = existing["type"]
            if kind in {"payable", "receivable"}:
                return jsonify({"error": "Payable/receivable entries are ledger records and cannot be edited. Add a settlement entry instead."}), 400
            values = validate_record(data, kind)
            values["id"] = rec_id
            conn.execute("""UPDATE records SET date=:date, amount=:amount, source=:source,
                category=:category, name=:name, method=:method, status=:status,
                note=:note, from_method=:from_method WHERE id=:id AND user_id=:user_id""", {**values, "user_id": current_user_id()})
        return jsonify({"success": True, "id": rec_id})
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except sqlite3.Error:
        app.logger.exception("Database error updating record")
        return jsonify({"error": "Database operation failed"}), 500


@app.route("/api/records/<rec_id>/settlements", methods=["POST"])
@login_required
def create_settlement(rec_id):
    data = json_body()
    try:
        amount = parse_amount(data.get("amount"))
        date_value = validate_date(data.get("date"))
        method = clean_text(data.get("method"), "Account", required=True)
        with get_db() as conn:
            parent = conn.execute("SELECT * FROM records WHERE id=? AND user_id=? AND type IN ('payable','receivable')", (rec_id, current_user_id())).fetchone()
            if not parent:
                return jsonify({"error": "Payable/receivable entry not found"}), 404
            paid = float(conn.execute("SELECT COALESCE(SUM(amount),0) FROM settlements WHERE parent_id=?", (rec_id,)).fetchone()[0])
            outstanding = round(float(parent["amount"]) - paid, 2)
            if amount > outstanding + 0.001:
                raise ValueError(f"Amount exceeds outstanding balance ({outstanding:.2f})")
            sid = "stl_" + uuid.uuid4().hex
            conn.execute("INSERT INTO settlements(id,parent_id,date,amount,method) VALUES(?,?,?,?,?)", (sid, rec_id, date_value, amount, method))
        return jsonify({"success": True, "id": sid, "outstanding": round(outstanding-amount,2)}), 201
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except sqlite3.Error:
        app.logger.exception("Database error creating settlement")
        return jsonify({"error": "Database operation failed"}), 500


if __name__ == "__main__":
    # Debug mode is deliberately disabled; configure credentials through environment variables.
    app.run(host=os.environ.get("FINANCE_HOST", "127.0.0.1"), port=int(os.environ.get("PORT", "5000")), debug=False)
