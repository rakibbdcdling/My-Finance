# My Finance App

A multi-user personal-finance tracker built with Flask, SQLite, HTML, CSS and JavaScript.

## Features
- Public self-service account registration with email OTP verification and Email/Password login
- Passwordless Master Admin login using a one-time email code
- Signup email screening: syntax, disposable-domain feeds, DNS/MX and conservative SMTP RCPT probing; inconclusive DNS/SMTP checks fail open
- Disposable-domain feeds are cached locally and refreshed automatically at most once per 24 hours; temporary feed/network failures retain the last good cache
- Master Admin can manage custom email-domain allow/block rules and manually refresh disposable-domain feeds
- Signup fields: Full Name, Email, Phone Number, Password, Confirm Password
- Passwords are stored as salted password hashes; plain-text passwords are never stored
- Every user has a separate private ledger; records, settlements and custom dropdown options are scoped to the signed-in account
- Same account can be used from multiple browsers/devices; data is shared through the central server database
- Income, expense, Cash & Bank account tracking, dashboard month/year filters and search
- Payables/receivables with linked partial settlement history
- Each entry in all five tabs can be permanently deleted; linked settlement history is deleted with its parent entry
- Deleted entries are excluded from calculations and SQLite is compacted with VACUUM
- Existing single-user database rows are migrated to the legacy `admin@localhost` account rather than exposed to new signups

## Requirements
Python 3.10+ and Flask 3.x. For production hosting on Linux, Gunicorn is included.

Install:
```bash
python -m pip install -r requirements.txt
```

Local development:
```bash
python app.py
```
Then open http://127.0.0.1:5000.

## Important: use across different devices / Wi-Fi
Multi-device access requires one always-on, internet-accessible server. Do **not** run a separate copy of this app and a separate `finance.db` on each device. Deploy this project once to a VPS or a hosting platform that supports a persistent disk, then all devices sign in to the same HTTPS website. SQLite is stored on that server's persistent disk, not in the browser.

For a Linux host, configure:
- `PORT`: supplied by the hosting provider
- `FINANCE_DB_PATH=/var/data/finance.db` (replace `/var/data` with the mounted persistent-disk path)
- `FINANCE_SECRET_KEY`: a long, random, permanent secret; do not change it between deployments
- `FINANCE_COOKIE_SECURE=1` when HTTPS is enabled

The included `Procfile` starts Gunicorn. Attach a persistent disk to the service and ensure the configured database directory exists and is writable. Back up the persistent database regularly. Do not use an ephemeral container filesystem for `finance.db`, because redeployments may erase it. For heavier concurrent workloads, migrate SQLite to PostgreSQL before scaling horizontally.

## Security notes
- Use HTTPS in production.
- Choose a strong, unique password.
- Each account can access only its own records and custom dropdown values.
- Signup and Master Admin login require email OTP delivery. Configure the SMTP variables below on the hosting account; password-reset emails are not currently provided.

## Deleting entries
Delete from Income, Expenses, Payables, Receivables or Cash & Banks. The app asks for confirmation, deletes linked settlements where applicable, reloads records and recalculates all views. SQLite VACUUM reclaims unused database pages.

## Ledger behavior
- Payable principal: increases the selected account and liability, but is not income.
- Receivable principal: decreases the selected account and increases receivable asset, but is not expense.
- Payable settlement: decreases the selected account and outstanding liability.
- Receivable settlement: increases the selected account and reduces outstanding receivable.
- Internal account transfers do not change total assets.

## Tests
```bash
python -m unittest discover -s tests -v
```
The tests cover ledger behavior, deletion, signup/login and user-data isolation.

## Master Admin login

The Master Admin signs in without a password. On the Login screen, select **“If you are admin, Login here.”** A one-time code is sent to the server-configured `MASTER_ADMIN_EMAIL`; the screen only displays a generic confirmation and never reveals the destination address. Enter the six-digit code to finish signing in. Codes expire after five minutes.

Signup email verification uses the same SMTP delivery configuration. Configure these environment variables on the hosting account:

- `MASTER_ADMIN_EMAIL`: destination for Master Admin login codes
- `SMTP_HOST`, `SMTP_PORT`
- `SMTP_USERNAME`, `SMTP_PASSWORD`
- `SMTP_FROM`
- `SMTP_USE_SSL=1` for implicit TLS; otherwise STARTTLS is used

Keep SMTP credentials and the Master Admin destination private. Do not put production secrets in source control.

## Disposable email detection behavior

The app merges several free community blocklists (disposable-email-domains, 7c/fakefilter, FGRibreau/mailchecker and wesbos/burner-email-providers) into a local cache. It refreshes at most every 24 hours and keeps the last successful cache if remote feeds are unavailable. Exact known disposable domains and provider-specific disposable MX fingerprints are blocked; generic MX providers (for example shared cloud mail hosts) are not blocked based on fingerprint alone. Master Admin custom `block` rules override the global list; custom `allow` rules bypass disposable-list and disposable-MX matches but do not bypass syntax or DNS/MX checks. Missing MX and invalid DNS are rejected. DNS timeouts and inconclusive SMTP results fail open; explicit permanent mailbox-not-found responses are rejected. SMTP RCPT probing does not send a message or issue SMTP DATA; signup sends an OTP only after screening.

No blocklist can identify every temporary-mail provider. New/obscure domains may be missed until a source adds them or the Admin blocks them manually.
