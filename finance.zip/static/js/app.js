// Constant Data Registries matching TSX exactly
let DEFAULT_NAMES = ['GM', 'Habib Bhai', 'Bhoumik Bhai'];
let DEFAULT_METHODS = ['Cash', 'Meghna Bank', 'Bkash', 'Bank Asia'];
let DEFAULT_CATEGORIES = [
  'Snack', 'Meal Cost', 'Mobile Recharge', 'Hostel Rent', 
  'Home Visite', 'Medicine', 'Service Charge', 'Abba', 'Others'
];
let DEFAULT_SOURCES = ['Salary', 'Freelance', 'Bonus', 'Investment', 'Business', 'Gift', 'Others'];

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const MONTH_ABBR = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

const YEARS = Array.from({ length: 12 }, (_, i) => String(2024 + i));

// Escape all user/database-controlled values before inserting them into HTML.
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>\"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[ch]));
}

function localDateTimeValue(date = new Date()) {
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

// Pill Style Mappings
const CATEGORY_STYLES = {
  'Snack': 'bg-pink-100 text-pink-700 border-pink-200',
  'Meal Cost': 'bg-amber-100 text-amber-800 border-amber-200',
  'Abba': 'bg-emerald-100 text-emerald-800 border-emerald-200',
  'Mobile Recharge': 'bg-indigo-100 text-indigo-800 border-indigo-200',
  'Hostel Rent': 'bg-violet-100 text-violet-800 border-violet-200',
  'Service Charge': 'bg-fuchsia-100 text-fuchsia-800 border-fuchsia-200',
  'Home Visite': 'bg-sky-100 text-sky-800 border-sky-200',
  'Medicine': 'bg-teal-100 text-teal-800 border-teal-200',
  'Others': 'bg-slate-100 text-slate-700 border-slate-200'
};

const SOURCE_STYLES = {
  'Salary': 'bg-emerald-100 text-emerald-800 border-emerald-200',
  'Freelance': 'bg-indigo-100 text-indigo-800 border-indigo-200',
  'Bonus': 'bg-amber-100 text-amber-800 border-amber-200',
  'Investment': 'bg-purple-100 text-purple-800 border-purple-200',
  'Business': 'bg-teal-100 text-teal-800 border-teal-200',
  'Gift': 'bg-pink-100 text-pink-700 border-pink-200',
  'Others': 'bg-slate-100 text-slate-700 border-slate-200'
};

const METHOD_STYLES = {
  'Cash': 'bg-[#006847] text-white',
  'Meghna Bank': 'bg-blue-100 text-[#00529b] border border-blue-200',
  'Bkash': 'bg-pink-100 text-[#d81b60] border border-pink-200',
  'Bank Asia': 'bg-emerald-100 text-[#166534] border border-emerald-200'
};

// Date Parsing and Formatting Helpers from TSX
function extractMonthAndYear(dateStr) {
  if (!dateStr) return { month: -1, year: -1 };
  const str = String(dateStr).trim();

  const isoMatch = str.match(/^(\d{4})[-/](\d{1,2})/);
  if (isoMatch) {
    return { year: parseInt(isoMatch[1], 10), month: parseInt(isoMatch[2], 10) - 1 };
  }

  const yearMatch = str.match(/\b(20\d{2})\b/);
  const year = yearMatch ? parseInt(yearMatch[1], 10) : -1;

  for (let i = 0; i < 12; i++) {
    const fullPattern = new RegExp(`\\b${MONTH_NAMES[i]}\\b`, 'i');
    const abbrPattern = new RegExp(`\\b${MONTH_ABBR[i]}\\b`, 'i');
    if (fullPattern.test(str) || abbrPattern.test(str)) {
      return { month: i, year };
    }
  }

  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) {
    return { month: parsed.getMonth(), year: parsed.getFullYear() };
  }

  return { month: -1, year: -1 };
}

function formatToDisplayDate(dateVal) {
  const d = dateVal ? new Date(dateVal) : new Date();
  const day = String(d.getDate()).padStart(2, '0');
  const month = MONTH_ABBR[d.getMonth()];
  const year = d.getFullYear();
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  const seconds = String(d.getSeconds()).padStart(2, '0');
  return `${day} ${month}, ${year} ${hours}:${minutes}:${seconds}`;
}

function parseToInputDateTime(dateStr) {
  if (!dateStr) return localDateTimeValue();
  try {
    const d = new Date(dateStr);
    if (!isNaN(d.getTime())) {
      const offset = d.getTimezoneOffset() * 60000;
      return new Date(d.getTime() - offset).toISOString().slice(0, 16);
    }
  } catch (err) {}
  return localDateTimeValue();
}

// App State
let currentUser = { username: 'admin', name: 'Finance Admin', role: 'Primary Account Holder' };
let isAuthenticated = false;
let activeTab = 'dashboard';
let selectedMonth = MONTH_NAMES[new Date().getMonth()];
let selectedYear = String(new Date().getFullYear());
let highlightedId = null;

let records = {
  incomes: [],
  expenses: [],
  payables: [],
  receivables: [],
  bankTxns: []
};

// Modal Custom Input State
let isAddingNewSource = false;
let isAddingNewCategory = false;
let isAddingNewName = false;
let isAddingNewMethod = false;

// Search terms per tab
let searchTerms = {
  income: '',
  expense: '',
  payable: '',
  receivable: '',
  bankTxn: ''
};

// Start application
document.addEventListener('DOMContentLoaded', () => {
  initLiveClock();
  setupEventListeners();
  checkAuth();
});

function initLiveClock() {
  const update = () => {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = MONTH_ABBR[now.getMonth()];
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const str = `${day} ${month}, ${year} ${hours}:${minutes}:${seconds}`;
    const el = document.getElementById('formattedLiveClock');
    if (el) el.innerText = str;
  };
  update();
  setInterval(update, 1000);
}

async function checkAuth() {
  try {
    const res = await fetch('/api/auth/status');
    const data = await res.json();
    if (data.authenticated) {
      currentUser = data.user;
      isAuthenticated = true;
      document.getElementById('authScreen').classList.add('hidden');
      document.getElementById('mainApp').classList.remove('hidden');
      document.getElementById('drawerUserLabel').innerText = `User: ${currentUser.username}`;
      applyRoleLayout();
      if (currentUser.role === 'master_admin') {
        await loadMasterAdminPanel();
      } else {
        await loadMetaData();
        await fetchAllRecords();
      }
    } else {
      document.getElementById('authScreen').classList.remove('hidden');
      document.getElementById('mainApp').classList.add('hidden');
    }
  } catch (e) {
    document.getElementById('authScreen').classList.remove('hidden');
    document.getElementById('mainApp').classList.add('hidden');
  } finally {
    document.documentElement.classList.remove('auth-pending');
  }
}

async function loadMetaData() {
  try {
    const res = await fetch('/api/meta');
    const meta = await res.json();
    if (meta.sources) meta.sources.forEach(s => { if (!DEFAULT_SOURCES.includes(s)) DEFAULT_SOURCES.push(s); });
    if (meta.categories) meta.categories.forEach(c => { if (!DEFAULT_CATEGORIES.includes(c)) DEFAULT_CATEGORIES.push(c); });
    if (meta.names) meta.names.forEach(n => { if (!DEFAULT_NAMES.includes(n)) DEFAULT_NAMES.push(n); });
    if (meta.methods) meta.methods.forEach(m => { if (!DEFAULT_METHODS.includes(m)) DEFAULT_METHODS.push(m); });
  } catch (err) {}
  populateYearMonthDropdowns();
}

function populateYearMonthDropdowns() {
  const mSel = document.getElementById('selectedMonth');
  mSel.innerHTML = '';
  MONTH_NAMES.forEach(m => {
    mSel.innerHTML += `<option value="${escapeHtml(m)}" ${m === selectedMonth ? 'selected' : ''}>${escapeHtml(m)}</option>`;
  });

  const ySel = document.getElementById('selectedYear');
  ySel.innerHTML = '';
  const yearOptions = [...new Set([...YEARS, String(new Date().getFullYear()), selectedYear])].sort();
  yearOptions.forEach(y => {
    ySel.innerHTML += `<option value="${escapeHtml(y)}" ${y === selectedYear ? 'selected' : ''}>${escapeHtml(y)}</option>`;
  });
}

function triggerDbSaveIndicator() {
  const icon = document.getElementById('dbStatusIcon');
  const txt = document.getElementById('dbStatusText');
  if (icon && txt) {
    icon.classList.add('text-amber-400', 'animate-spin');
    icon.classList.remove('text-emerald-400');
    txt.innerText = 'Syncing...';
    setTimeout(() => {
      icon.classList.remove('text-amber-400', 'animate-spin');
      icon.classList.add('text-emerald-400');
      txt.innerText = 'SQLite Connected';
    }, 350);
  }
}

async function fetchAllRecords() {
  triggerDbSaveIndicator();
  try {
    const res = await fetch('/api/records');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not load records');
    records = data;
    renderAllViews();
  } catch (err) {
    console.error(err);
    const status = document.getElementById('dbStatusText');
    if (status) status.innerText = 'Database unavailable';
  }
}

// Apply the same role-specific layout after login and after session restoration.
function applyRoleLayout() {
  const isMasterAdmin = currentUser?.role === 'master_admin';
  const adminPanel = document.getElementById('masterAdminPanel');
  const mainApp = document.getElementById('mainApp');
  if (adminPanel) adminPanel.classList.toggle('hidden', !isMasterAdmin);
  if (mainApp) mainApp.classList.toggle('master-admin-mode', isMasterAdmin);
  if (isMasterAdmin) {
    activeTab = 'masterAdmin';
    closeMobileDrawer();
  } else if (activeTab === 'masterAdmin') {
    activeTab = 'dashboard';
  }
}

// Compute Balances exact as TSX
function computeAccountBalances() {
  const balances = {};
  DEFAULT_METHODS.forEach(m => { balances[m] = 0; });

  records.bankTxns.forEach(tx => {
    const amt = parseFloat(tx.amount) || 0;
    const m = tx.method;
    if (balances[m] === undefined) balances[m] = 0;

    if (tx.note && tx.note.startsWith('From ')) {
      const fromM = tx.fromMethod || tx.note.replace('From ', '').trim();
      if (balances[fromM] === undefined) balances[fromM] = 0;
      balances[fromM] -= amt;
      balances[m] += amt;
    } else {
      balances[m] += amt;
    }
  });

  records.incomes.forEach(inc => {
    const amt = parseFloat(inc.amount) || 0;
    if (balances[inc.method] === undefined) balances[inc.method] = 0;
    balances[inc.method] += amt;
  });

  records.expenses.forEach(exp => {
    const amt = parseFloat(exp.amount) || 0;
    if (balances[exp.method] === undefined) balances[exp.method] = 0;
    balances[exp.method] -= amt;
  });

  // Loan received: cash/bank increases immediately; later repayment decreases it.
  records.payables.forEach(p => {
    if (balances[p.method] === undefined) balances[p.method] = 0;
    balances[p.method] += Number(p.amount) || 0;
    (p.settlements || []).forEach(st => {
      if (balances[st.method] === undefined) balances[st.method] = 0;
      balances[st.method] -= Number(st.amount) || 0;
    });
  });

  // Loan given: cash/bank decreases immediately; later collection increases it.
  records.receivables.forEach(r => {
    if (balances[r.method] === undefined) balances[r.method] = 0;
    balances[r.method] -= Number(r.amount) || 0;
    (r.settlements || []).forEach(st => {
      if (balances[st.method] === undefined) balances[st.method] = 0;
      balances[st.method] += Number(st.amount) || 0;
    });
  });

  return balances;
}

// Metrics exact calculation as TSX
function computeMetrics() {
  const selectedMonthIndex = MONTH_NAMES.indexOf(selectedMonth);
  const selectedYearNum = parseInt(selectedYear, 10);

  const isDateInActivePeriod = (dateStr) => {
    const { month, year } = extractMonthAndYear(dateStr);
    return month === selectedMonthIndex && year === selectedYearNum;
  };

  const periodIncomes = records.incomes.filter(inc => isDateInActivePeriod(inc.date));
  const periodExpenses = records.expenses.filter(exp => isDateInActivePeriod(exp.date));

  const totalIncome = periodIncomes.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
  const totalExpenses = periodExpenses.reduce((s, i) => s + (parseFloat(i.amount) || 0), 0);
  const balances = computeAccountBalances();
  // Net cash position: negative account balances must offset positive balances.
  const liquidAssets = Object.values(balances).reduce((s, v) => s + v, 0);
  const accountsReceivable = records.receivables
    .reduce((s, r) => s + (Number(r.outstanding ?? r.amount) || 0), 0);
  const accountsPayable = records.payables
    .reduce((s, p) => s + (Number(p.outstanding ?? p.amount) || 0), 0);
  const netSurplus = totalIncome - totalExpenses;
  const netProjected = liquidAssets + accountsReceivable - accountsPayable;

  return {
    totalIncome,
    totalExpenses,
    netSurplus,
    liquidAssets,
    accountsReceivable,
    accountsPayable,
    netProjected,
    periodIncomes,
    periodExpenses,
    accountBalances: balances
  };
}

function renderAllViews() {
  const m = computeMetrics();

  // Top Dashboard Metrics
  document.getElementById('metricIncome').innerText = `৳${m.totalIncome.toLocaleString()}`;
  document.getElementById('metricExpenses').innerText = `৳${m.totalExpenses.toLocaleString()}`;
  const surplusEl = document.getElementById('metricSurplus');
  surplusEl.innerText = `৳${m.netSurplus.toLocaleString()}`;
  surplusEl.className = `text-2xl sm:text-3xl font-black tracking-tight ${m.netSurplus < 0 ? 'text-rose-600' : 'text-[#006847]'}`;
  document.getElementById('metricLiquid').innerText = `৳${m.liquidAssets.toLocaleString()}`;
  document.getElementById('metricReceivable').innerText = `৳${m.accountsReceivable.toLocaleString()}`;
  document.getElementById('metricPayable').innerText = `৳${m.accountsPayable.toLocaleString()}`;
  document.getElementById('metricProjected').innerText = `৳${m.netProjected.toLocaleString()}`;

  // Drawer Metrics
  document.getElementById('drawerLiquidAssets').innerText = `৳${m.liquidAssets.toLocaleString()}`;
  document.getElementById('drawerNetSurplus').innerText = `৳${m.netSurplus.toLocaleString()}`;

  // Top 5 Expenses
  renderTopExpenses(m.periodExpenses, m.totalExpenses);

  // Accounts & Balances
  renderAccountsAndBalances(m.accountBalances, m.liquidAssets);

  // Tab Ledgers & Summaries
  renderIncomeTab();
  renderExpensesTab();
  renderPayablesTab();
  renderReceivablesTab();
  renderCashBanksTab();

  lucide.createIcons();
}

function renderTopExpenses(periodExpenses, totalExpenses) {
  document.getElementById('topExpensePeriodTag').innerText = `${selectedMonth} ${selectedYear}`;
  const tbody = document.getElementById('topExpensesTableBody');
  tbody.innerHTML = '';

  if (periodExpenses.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" class="py-8 text-center text-slate-400 font-medium">No expenses recorded for ${selectedMonth}, ${selectedYear}</td></tr>`;
    return;
  }

  const map = {};
  periodExpenses.forEach(exp => {
    const cat = exp.category;
    if (!map[cat]) map[cat] = { category: cat, entries: 0, total: 0 };
    map[cat].entries += 1;
    map[cat].total += parseFloat(exp.amount) || 0;
  });

  const list = Object.values(map).sort((a, b) => b.total - a.total);
  const top4 = list.slice(0, 4);
  const rest = list.slice(4);

  let finalTop = [...top4];
  if (rest.length > 0) {
    const restTotal = rest.reduce((s, i) => s + i.total, 0);
    const restEntries = rest.reduce((s, i) => s + i.entries, 0);
    finalTop.push({ category: 'Others', entries: restEntries, total: restTotal });
  }

  const grandTotal = totalExpenses || 1;
  finalTop.forEach(row => {
    const share = ((row.total / grandTotal) * 100).toFixed(1);
    tbody.innerHTML += `
      <tr class="hover:bg-emerald-50/40 transition-colors">
        <td class="py-3 px-4 font-bold text-slate-800">${escapeHtml(row.category)}</td>
        <td class="py-3 px-4 text-center text-slate-600 font-semibold">${row.entries}</td>
        <td class="py-3 px-4 text-right font-black text-slate-900">৳${row.total.toLocaleString()}</td>
        <td class="py-3 px-4 text-right text-slate-600 font-bold">${share}%</td>
      </tr>`;
  });
}

function renderAccountsAndBalances(balances, liquidTotal) {
  const tbody = document.getElementById('accountsTableBody');
  tbody.innerHTML = '';

  DEFAULT_METHODS.forEach(accName => {
    const bal = balances[accName] ?? 0;
    let typeLabel = 'Bank Account';
    if (accName.toLowerCase().includes('cash')) typeLabel = 'Physical Cash';
    else if (accName.toLowerCase().includes('kash') || accName.toLowerCase().includes('nagad') || accName.toLowerCase().includes('rocket')) {
      typeLabel = 'Mobile Banking';
    }

    tbody.innerHTML += `
      <tr class="hover:bg-emerald-50/40 transition-colors">
        <td class="py-3 px-4 font-bold text-slate-900">${escapeHtml(accName)}</td>
        <td class="py-3 px-4 text-slate-500 font-medium text-xs">${typeLabel}</td>
        <td class="py-3 px-4 text-center">
          <span class="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">Active</span>
        </td>
        <td class="py-3 px-4 text-right font-black text-slate-900">${bal < 0 ? '-৳' + Math.abs(bal).toLocaleString() : '৳' + bal.toLocaleString()}</td>
      </tr>`;
  });

  document.getElementById('totalLiquidFooter').innerText = `৳${liquidTotal.toLocaleString()}`;
}

// 1. Income Tab
function renderIncomeTab() {
  const map = {};
  records.incomes.forEach(inc => {
    const src = inc.source || 'Others';
    if (!map[src]) map[src] = { count: 0, total: 0 };
    map[src].count += 1;
    map[src].total += parseFloat(inc.amount) || 0;
  });

  const grid = document.getElementById('incomeSourceSummaryGrid');
  grid.innerHTML = '';
  const entries = Object.entries(map);
  if (entries.length === 0) {
    grid.innerHTML = `<div class="col-span-full bg-white p-4 rounded-xl border border-dashed border-slate-300 text-slate-400 text-xs text-center">No income sources recorded yet.</div>`;
  } else {
    entries.forEach(([source, val]) => {
      grid.innerHTML += `
        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div class="flex items-center justify-between mb-1">
            <span class="text-xs font-black text-slate-800">${escapeHtml(source)}</span>
            <span class="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
              ${val.count} ${val.count > 1 ? 'entries' : 'entry'}
            </span>
          </div>
          <span class="text-lg font-black text-emerald-700">৳${val.total.toLocaleString()}</span>
        </div>`;
    });
  }

  const s = searchTerms.income.toLowerCase();
  const filtered = records.incomes.filter(i =>
    (i.source || '').toLowerCase().includes(s) ||
    (i.method || '').toLowerCase().includes(s) ||
    (i.date || '').toLowerCase().includes(s)
  );

  const totalInc = records.incomes.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0);
  document.getElementById('incomeTabTotal').innerText = `৳${totalInc.toLocaleString()}`;
  document.getElementById('incomeCountBadge').innerText = `${records.incomes.length} Total Records`;

  const tbody = document.getElementById('incomeTableBody');
  tbody.innerHTML = '';
  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="py-12 text-center text-slate-400 font-medium text-xs sm:text-sm">No income records found. Click "+ Add Income" to record a new entry.</td></tr>`;
    return;
  }

  filtered.forEach(inc => {
    const isHigh = highlightedId === inc.id;
    const srcStyle = SOURCE_STYLES[inc.source] || SOURCE_STYLES['Others'];
    const mStyle = METHOD_STYLES[inc.method] || 'bg-slate-200 text-slate-800';

    tbody.innerHTML += `
      <tr class="hover:bg-slate-50 transition-colors ${isHigh ? 'row-highlight' : ''}">
        <td class="py-3 px-4 text-slate-700 whitespace-nowrap text-xs font-semibold">${escapeHtml(inc.date)}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3.5 py-1 rounded-full text-xs font-bold border ${srcStyle}">${escapeHtml(inc.source)}</span>
        </td>
        <td class="py-3 px-4 text-right font-black text-slate-900 text-sm">৳${parseFloat(inc.amount).toLocaleString()}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3.5 py-1 rounded-full text-xs font-semibold shadow-xs ${mStyle}">${escapeHtml(inc.method)}</span>
        </td>
        <td class="py-3 px-4 text-center whitespace-nowrap">
          <div class="inline-flex items-center space-x-1">
            <button onclick="openEditModal('income', '${inc.id}')" class="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition active:scale-90" title="Edit Entry">
              <i data-lucide="edit-3" class="w-4 h-4"></i>
            </button>
            <button onclick="deleteRecord('${inc.id}', 'income')" class="p-2 text-rose-600 hover:text-white hover:bg-rose-600 rounded-lg transition active:scale-90" title="Delete Entry" aria-label="Delete Entry"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
          </div>
        </td>
      </tr>`;
  });
}

// 2. Expenses Tab
function renderExpensesTab() {
  const map = {};
  records.expenses.forEach(exp => {
    const cat = exp.category || 'Others';
    if (!map[cat]) map[cat] = { count: 0, total: 0 };
    map[cat].count += 1;
    map[cat].total += parseFloat(exp.amount) || 0;
  });

  const grid = document.getElementById('expenseCategorySummaryGrid');
  grid.innerHTML = '';
  const entries = Object.entries(map).sort((a, b) => b[1].total - a[1].total);
  if (entries.length === 0) {
    grid.innerHTML = `<div class="col-span-full bg-white p-4 rounded-xl border border-dashed border-slate-300 text-slate-400 text-xs text-center">No expense categories recorded yet.</div>`;
  } else {
    entries.forEach(([category, val]) => {
      grid.innerHTML += `
        <div class="bg-white p-3 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div class="flex items-center justify-between mb-1">
            <span class="text-xs font-black text-slate-800 truncate" title="${escapeHtml(category)}">${escapeHtml(category)}</span>
            <span class="text-[10px] font-bold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full">${val.count}</span>
          </div>
          <span class="text-base sm:text-lg font-black text-rose-700">৳${val.total.toLocaleString()}</span>
        </div>`;
    });
  }

  const s = searchTerms.expense.toLowerCase();
  const filtered = records.expenses.filter(e =>
    (e.category || '').toLowerCase().includes(s) ||
    (e.method || '').toLowerCase().includes(s) ||
    (e.date || '').toLowerCase().includes(s)
  );

  const totalExp = records.expenses.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0);
  document.getElementById('expenseTabTotal').innerText = `৳${totalExp.toLocaleString()}`;
  document.getElementById('expenseCountBadge').innerText = `${records.expenses.length} Total Records`;

  const tbody = document.getElementById('expenseTableBody');
  tbody.innerHTML = '';
  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="py-12 text-center text-slate-400 font-medium text-xs sm:text-sm">No expenses recorded. Click "+ Add Expense" to record an expense.</td></tr>`;
    return;
  }

  filtered.forEach(exp => {
    const isHigh = highlightedId === exp.id;
    const catStyle = CATEGORY_STYLES[exp.category] || CATEGORY_STYLES['Others'];
    const mStyle = METHOD_STYLES[exp.method] || 'bg-slate-200 text-slate-800';

    tbody.innerHTML += `
      <tr class="hover:bg-slate-50 transition-colors ${isHigh ? 'row-highlight' : ''}">
        <td class="py-3 px-4 text-slate-700 whitespace-nowrap text-xs font-semibold">${escapeHtml(exp.date)}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3.5 py-1 rounded-full text-xs font-bold border ${catStyle}">${escapeHtml(exp.category)}</span>
        </td>
        <td class="py-3 px-4 text-right font-black text-slate-900 text-sm">৳${parseFloat(exp.amount).toLocaleString()}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3.5 py-1 rounded-full text-xs font-semibold shadow-xs ${mStyle}">${escapeHtml(exp.method)}</span>
        </td>
        <td class="py-3 px-4 text-center whitespace-nowrap">
          <div class="inline-flex items-center space-x-1">
            <button onclick="openEditModal('expense', '${exp.id}')" class="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition active:scale-90" title="Edit Entry">
              <i data-lucide="edit-3" class="w-4 h-4"></i>
            </button>
            <button onclick="deleteRecord('${exp.id}', 'expense')" class="p-2 text-rose-600 hover:text-white hover:bg-rose-600 rounded-lg transition active:scale-90" title="Delete Entry" aria-label="Delete Entry"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
          </div>
        </td>
      </tr>`;
  });
}

// 3. Payables Tab
function renderPayablesTab() {
  const map = {};
  records.payables.forEach(p => {
    const name = p.name || 'Unknown';
    if (!map[name]) map[name] = { count: 0, total: 0, unpaid: 0, paid: 0 };
    map[name].count += 1;
    const amt = parseFloat(p.amount) || 0;
    map[name].total += amt;
    map[name].unpaid += Number(p.outstanding ?? p.amount) || 0;
    map[name].paid += Number(p.settled) || 0;
  });

  const grid = document.getElementById('payableSummaryGrid');
  grid.innerHTML = '';
  const entries = Object.entries(map);
  if (entries.length === 0) {
    grid.innerHTML = `<div class="col-span-full bg-white p-4 rounded-xl border border-dashed border-slate-300 text-slate-400 text-xs text-center">No payable accounts recorded.</div>`;
  } else {
    entries.forEach(([name, val]) => {
      grid.innerHTML += `
        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div class="flex items-center justify-between mb-1">
            <span class="text-xs font-black text-slate-800">${escapeHtml(name)}</span>
            <span class="text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">
              ${val.count} ${val.count > 1 ? 'bills' : 'bill'}
            </span>
          </div>
          <div class="flex items-center justify-between mt-2 text-xs">
            <span class="text-slate-500 font-semibold">Remaining Due:</span>
            <span class="font-black text-rose-700">৳${val.unpaid.toLocaleString()}</span>
          </div>
        </div>`;
    });
  }

  const due = records.payables.reduce((s, p) => s + (Number(p.outstanding ?? p.amount) || 0), 0);
  document.getElementById('payableDueBadge').innerText = `Due: ৳${due.toLocaleString()}`;
  document.getElementById('payableCountBadge').innerText = `${records.payables.length} Total Records`;

  const tbody = document.getElementById('payableTableBody');
  tbody.innerHTML = '';
  const term = (searchTerms.payable || '').toLowerCase();
  const filteredPayables = records.payables.filter(item =>
    [item.name, item.method, item.date, item.status].some(value => String(value || '').toLowerCase().includes(term))
  );
  if (filteredPayables.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="py-12 text-center text-slate-400 font-medium text-xs sm:text-sm">${records.payables.length ? 'No matching payables found.' : 'No payables recorded. Click "+ Add Payable" to add an entry.'}</td></tr>`;
    return;
  }

  filteredPayables.forEach(item => {
    const isHigh = highlightedId === item.id;
    const mStyle = METHOD_STYLES[item.method] || 'bg-slate-200 text-slate-800';
    const isPaid = item.status === 'Paid';

    tbody.innerHTML += `
      <tr class="hover:bg-slate-50 transition-colors ${isHigh ? 'row-highlight' : ''}">
        <td class="py-3 px-4 text-slate-700 text-xs font-semibold whitespace-nowrap">${escapeHtml(item.date)}</td>
        <td class="py-3 px-4 font-bold text-slate-900">${escapeHtml(item.name)}</td>
        <td class="py-3 px-4 text-right font-black text-slate-900">৳${parseFloat(item.amount).toLocaleString()}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${mStyle}">${escapeHtml(item.method)}</span>
        </td>
        <td class="py-3 px-4 text-center"><span class="text-xs font-bold ${item.outstanding <= 0.001 ? 'text-emerald-700' : 'text-rose-700'}">${item.outstanding <= 0.001 ? 'Paid' : 'Unpaid'}</span></td>
        <td class="py-3 px-4 text-right font-black text-slate-900">৳${Number(item.outstanding ?? item.amount).toLocaleString()}</td>
        <td class="py-3 px-4 text-center whitespace-nowrap">${item.outstanding > 0.001 ? `<button onclick="addSettlement('${item.id}', '${item.method}', ${item.outstanding}, 'payable')" class="px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-bold">Add Payment</button>` : '<span class="text-xs text-emerald-700 font-bold">Settled</span>'}<details class="text-left mt-1"><summary class="cursor-pointer text-[10px] text-slate-500">History (${(item.settlements || []).length})</summary>${(item.settlements || []).map(st => `<div class="text-[10px] text-slate-500">${escapeHtml(st.date)} · ${escapeHtml(st.method)} · ৳${Number(st.amount).toLocaleString()}</div>`).join('')}</details><button onclick="deleteRecord('${item.id}', 'payable')" class="mt-2 inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-600 hover:text-white text-xs font-bold transition" title="Delete Entry"><i data-lucide="trash-2" class="w-3.5 h-3.5"></i> Delete</button></td>
      </tr>`;
  });
}

// 4. Receivables Tab
function renderReceivablesTab() {
  const map = {};
  records.receivables.forEach(r => {
    const name = r.name || 'Unknown';
    if (!map[name]) map[name] = { count: 0, total: 0, unpaid: 0, paid: 0 };
    map[name].count += 1;
    const amt = parseFloat(r.amount) || 0;
    map[name].total += amt;
    map[name].unpaid += Number(r.outstanding ?? r.amount) || 0;
    map[name].paid += Number(r.settled) || 0;
  });

  const grid = document.getElementById('receivableSummaryGrid');
  grid.innerHTML = '';
  const entries = Object.entries(map);
  if (entries.length === 0) {
    grid.innerHTML = `<div class="col-span-full bg-white p-4 rounded-xl border border-dashed border-slate-300 text-slate-400 text-xs text-center">No receivable accounts recorded.</div>`;
  } else {
    entries.forEach(([name, val]) => {
      grid.innerHTML += `
        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div class="flex items-center justify-between mb-1">
            <span class="text-xs font-black text-slate-800">${escapeHtml(name)}</span>
            <span class="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
              ${val.count} ${val.count > 1 ? 'items' : 'item'}
            </span>
          </div>
          <div class="flex items-center justify-between mt-2 text-xs">
            <span class="text-slate-500 font-semibold">To Collect:</span>
            <span class="font-black text-emerald-700">৳${val.unpaid.toLocaleString()}</span>
          </div>
        </div>`;
    });
  }

  const toCollect = records.receivables.reduce((s, r) => s + (Number(r.outstanding ?? r.amount) || 0), 0);
  document.getElementById('receivableDueBadge').innerText = `To Collect: ৳${toCollect.toLocaleString()}`;
  document.getElementById('receivableCountBadge').innerText = `${records.receivables.length} Total Records`;

  const tbody = document.getElementById('receivableTableBody');
  tbody.innerHTML = '';
  const term = (searchTerms.receivable || '').toLowerCase();
  const filteredReceivables = records.receivables.filter(item =>
    [item.name, item.method, item.date, item.status].some(value => String(value || '').toLowerCase().includes(term))
  );
  if (filteredReceivables.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="py-12 text-center text-slate-400 font-medium text-xs sm:text-sm">${records.receivables.length ? 'No matching receivables found.' : 'No receivables recorded. Click "+ Add Receivable" to add an entry.'}</td></tr>`;
    return;
  }

  filteredReceivables.forEach(item => {
    const isHigh = highlightedId === item.id;
    const mStyle = METHOD_STYLES[item.method] || 'bg-slate-200 text-slate-800';
    const isPaid = item.status === 'Paid';

    tbody.innerHTML += `
      <tr class="hover:bg-slate-50 transition-colors ${isHigh ? 'row-highlight' : ''}">
        <td class="py-3 px-4 text-slate-700 text-xs font-semibold whitespace-nowrap">${escapeHtml(item.date)}</td>
        <td class="py-3 px-4">
          <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-sky-700 text-white">${escapeHtml(item.name)}</span>
        </td>
        <td class="py-3 px-4 text-right font-black text-slate-900">৳${parseFloat(item.amount).toLocaleString()}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${mStyle}">${escapeHtml(item.method)}</span>
        </td>
        <td class="py-3 px-4 text-center"><span class="text-xs font-bold ${item.outstanding <= 0.001 ? 'text-emerald-700' : 'text-rose-700'}">${item.outstanding <= 0.001 ? 'Received' : 'Unpaid'}</span></td>
        <td class="py-3 px-4 text-right font-black text-slate-900">৳${Number(item.outstanding ?? item.amount).toLocaleString()}</td>
        <td class="py-3 px-4 text-center whitespace-nowrap">${item.outstanding > 0.001 ? `<button onclick="addSettlement('${item.id}', '${item.method}', ${item.outstanding}, 'receivable')" class="px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-bold">Add Receipt</button>` : '<span class="text-xs text-emerald-700 font-bold">Collected</span>'}<details class="text-left mt-1"><summary class="cursor-pointer text-[10px] text-slate-500">History (${(item.settlements || []).length})</summary>${(item.settlements || []).map(st => `<div class="text-[10px] text-slate-500">${escapeHtml(st.date)} · ${escapeHtml(st.method)} · ৳${Number(st.amount).toLocaleString()}</div>`).join('')}</details><button onclick="deleteRecord('${item.id}', 'receivable')" class="mt-2 inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-600 hover:text-white text-xs font-bold transition" title="Delete Entry"><i data-lucide="trash-2" class="w-3.5 h-3.5"></i> Delete</button></td>
      </tr>`;
  });
}

// 5. Cash & Banks Tab
function renderCashBanksTab() {
  const map = {};
  records.bankTxns.forEach(b => {
    const m = b.method || 'Cash';
    if (!map[m]) map[m] = { count: 0, total: 0 };
    map[m].count += 1;
    map[m].total += parseFloat(b.amount) || 0;
  });

  const grid = document.getElementById('bankTxnSummaryGrid');
  grid.innerHTML = '';
  const entries = Object.entries(map);
  if (entries.length === 0) {
    grid.innerHTML = `<div class="col-span-full bg-white p-4 rounded-xl border border-dashed border-slate-300 text-slate-400 text-xs text-center">No transactions recorded across accounts yet.</div>`;
  } else {
    entries.forEach(([method, val]) => {
      grid.innerHTML += `
        <div class="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div class="flex items-center justify-between mb-1">
            <span class="text-xs font-black text-slate-800">${escapeHtml(method)}</span>
            <span class="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
              ${val.count} txns
            </span>
          </div>
          <div class="mt-1">
            <span class="text-base sm:text-lg font-black text-[#004d3d]">৳${val.total.toLocaleString()}</span>
          </div>
        </div>`;
    });
  }

  document.getElementById('bankTxnCountBadge').innerText = `${records.bankTxns.length} Total Records`;

  const tbody = document.getElementById('bankTxnTableBody');
  tbody.innerHTML = '';
  const term = (searchTerms.bankTxn || '').toLowerCase();
  const filteredBankTxns = records.bankTxns.filter(txn =>
    [txn.method, txn.note, txn.date].some(value => String(value || '').toLowerCase().includes(term))
  );
  if (filteredBankTxns.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" class="py-12 text-center text-slate-400 font-medium text-xs sm:text-sm">${records.bankTxns.length ? 'No matching transactions found.' : 'No transactions recorded. Click "Record Deposit / Transfer" to begin.'}</td></tr>`;
    return;
  }

  filteredBankTxns.forEach(txn => {
    const isTransfer = (txn.note || '').startsWith('From ');
    const isHigh = highlightedId === txn.id;
    const mStyle = METHOD_STYLES[txn.method] || 'bg-slate-200 text-slate-800';

    tbody.innerHTML += `
      <tr class="hover:bg-slate-50 transition-colors ${isHigh ? 'row-highlight' : ''}">
        <td class="py-3 px-4 text-slate-700 text-xs font-semibold whitespace-nowrap">${escapeHtml(txn.date)}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3.5 py-1 rounded-full text-xs font-bold ${mStyle}">${escapeHtml(txn.method)}</span>
        </td>
        <td class="py-3 px-4 text-right font-black text-slate-900 text-sm">৳${parseFloat(txn.amount).toLocaleString()}</td>
        <td class="py-3 px-4 text-center">
          <span class="inline-flex items-center px-3.5 py-1 rounded-full text-xs font-black ${isTransfer ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-[#fee2e2] text-[#b91c1c] border border-rose-300'}">
            ${escapeHtml(txn.note)}
          </span>
        </td>
        <td class="py-3 px-4 text-center whitespace-nowrap">
          <div class="inline-flex items-center space-x-1">
            <button onclick="openEditModal('bankTxn', '${txn.id}')" class="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition active:scale-90" title="Edit Transaction">
              <i data-lucide="edit-3" class="w-4 h-4"></i>
            </button>
            <button onclick="deleteRecord('${txn.id}', 'bankTxn')" class="p-2 text-rose-600 hover:text-white hover:bg-rose-600 rounded-lg transition active:scale-90" title="Delete Entry" aria-label="Delete Entry"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
          </div>
        </td>
      </tr>`;
  });
}

// Modal Handlers (Unified Add and Edit)
function openModal(tabName, mode, editItem = null) {
  const modal = document.getElementById('entryModal');
  modal.classList.remove('hidden');
  const modalPanel = modal.querySelector('.modal-panel');
  if (modalPanel) {
    modalPanel.classList.remove('modal-enter');
    void modalPanel.offsetWidth;
    modalPanel.classList.add('modal-enter');
  }

  document.getElementById('modalTargetTab').value = tabName;
  document.getElementById('modalCurrentMode').value = mode;
  document.getElementById('modalModeTitle').innerText = mode === 'edit' ? 'Edit' : 'Add New';
  document.getElementById('modalTabTitle').innerText = tabName === 'bankTxn' ? 'Deposit / Transfer' : tabName;
  document.getElementById('saveModalSubmitBtn').innerText = mode === 'edit' ? 'Update Entry' : 'Save Entry';

  // Toggle Visibility of Fields
  document.getElementById('fieldSourceWrap').style.display = tabName === 'income' ? 'block' : 'none';
  document.getElementById('fieldCategoryWrap').style.display = tabName === 'expense' ? 'block' : 'none';
  document.getElementById('fieldNameWrap').style.display = (tabName === 'payable' || tabName === 'receivable') ? 'block' : 'none';
  document.getElementById('fieldNoteWrap').style.display = tabName === 'bankTxn' ? 'block' : 'none';

  document.getElementById('methodFieldLabel').innerText = tabName === 'bankTxn' ? 'Account' : tabName === 'payable' ? 'Received Into Account' : tabName === 'receivable' ? 'Paid From Account' : 'Payment Method';
  if (tabName === 'payable' || tabName === 'receivable') {
    document.getElementById('nameFieldLabel').innerText = tabName === 'payable' ? 'Payee Name' : 'Receivable From Name';
  }

  // Populate Selects
  populateModalOptions();

  // Reset custom toggles
  resetCustomInputs();

  if (mode === 'edit' && editItem) {
    document.getElementById('editingId').value = editItem.id;
    document.getElementById('formAmount').value = editItem.amount;
    document.getElementById('formDate').value = parseToInputDateTime(editItem.date);

    if (tabName === 'income') {
      document.getElementById('formSource').value = editItem.source || DEFAULT_SOURCES[0];
      document.getElementById('formMethod').value = editItem.method || DEFAULT_METHODS[0];
    } else if (tabName === 'expense') {
      document.getElementById('formCategory').value = editItem.category || DEFAULT_CATEGORIES[0];
      document.getElementById('formMethod').value = editItem.method || DEFAULT_METHODS[0];
    } else if (tabName === 'payable' || tabName === 'receivable') {
      document.getElementById('formName').value = editItem.name || DEFAULT_NAMES[0];
      document.getElementById('formMethod').value = editItem.method || DEFAULT_METHODS[0];
    } else if (tabName === 'bankTxn') {
      document.getElementById('formMethod').value = editItem.method || DEFAULT_METHODS[0];
      populateBankNoteOptions(editItem.method);
      document.getElementById('formNote').value = editItem.note || 'Deposit';
    }
  } else {
    document.getElementById('editingId').value = '';
    document.getElementById('formAmount').value = '';
    document.getElementById('formDate').value = localDateTimeValue();

    if (tabName === 'income') {
      document.getElementById('formSource').value = DEFAULT_SOURCES[0];
      document.getElementById('formMethod').value = DEFAULT_METHODS[0];
    } else if (tabName === 'expense') {
      document.getElementById('formCategory').value = DEFAULT_CATEGORIES[0];
      document.getElementById('formMethod').value = DEFAULT_METHODS[0];
    } else if (tabName === 'payable' || tabName === 'receivable') {
      document.getElementById('formName').value = DEFAULT_NAMES[0];
      document.getElementById('formMethod').value = DEFAULT_METHODS[0];
    } else if (tabName === 'bankTxn') {
      document.getElementById('formMethod').value = DEFAULT_METHODS[1] || 'Meghna Bank';
      populateBankNoteOptions(document.getElementById('formMethod').value);
    }
  }
}

function openEditModal(tabName, id) {
  let list = [];
  if (tabName === 'income') list = records.incomes;
  else if (tabName === 'expense') list = records.expenses;
  else if (tabName === 'payable') list = records.payables;
  else if (tabName === 'receivable') list = records.receivables;
  else if (tabName === 'bankTxn') list = records.bankTxns;

  const item = list.find(x => x.id === id);
  if (item) {
    openModal(tabName, 'edit', item);
  }
}

function closeModal() {
  document.getElementById('entryModal').classList.add('hidden');
}

function populateModalOptions() {
  const sSel = document.getElementById('formSource');
  sSel.innerHTML = '';
  DEFAULT_SOURCES.forEach(s => sSel.innerHTML += `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`);

  const cSel = document.getElementById('formCategory');
  cSel.innerHTML = '';
  DEFAULT_CATEGORIES.forEach(c => cSel.innerHTML += `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`);

  const nSel = document.getElementById('formName');
  nSel.innerHTML = '';
  DEFAULT_NAMES.forEach(n => nSel.innerHTML += `<option value="${escapeHtml(n)}">${escapeHtml(n)}</option>`);

  const mSel = document.getElementById('formMethod');
  mSel.innerHTML = '';
  DEFAULT_METHODS.forEach(m => mSel.innerHTML += `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`);
}

function populateBankNoteOptions(currentMethod) {
  const nSel = document.getElementById('formNote');
  nSel.innerHTML = '<option value="Deposit">Deposit (New Inflow)</option>';
  DEFAULT_METHODS.filter(m => m !== currentMethod).forEach(m => {
    nSel.innerHTML += `<option value="From ${escapeHtml(m)}">Transfer: From ${escapeHtml(m)}</option>`;
  });
}

function resetCustomInputs() {
  isAddingNewSource = false;
  isAddingNewCategory = false;
  isAddingNewName = false;
  isAddingNewMethod = false;

  document.getElementById('customSourceInputWrap').classList.add('hidden');
  document.getElementById('selectSourceWrap').classList.remove('hidden');
  document.getElementById('toggleAddSourceBtn').innerText = '+ Add New Source';
  document.getElementById('newCustomSource').value = '';

  document.getElementById('customCategoryInputWrap').classList.add('hidden');
  document.getElementById('selectCategoryWrap').classList.remove('hidden');
  document.getElementById('toggleAddCategoryBtn').innerText = '+ Add New Category';
  document.getElementById('newCustomCategory').value = '';

  document.getElementById('customNameInputWrap').classList.add('hidden');
  document.getElementById('selectNameWrap').classList.remove('hidden');
  document.getElementById('toggleAddNameBtn').innerText = '+ Add New Person';
  document.getElementById('newCustomName').value = '';

  document.getElementById('customMethodInputWrap').classList.add('hidden');
  document.getElementById('selectMethodWrap').classList.remove('hidden');
  document.getElementById('toggleAddMethodBtn').innerText = '+ Add New Method';
  document.getElementById('newCustomMethod').value = '';
}

// Toggle Custom vs Existing Inputs
function setupModalCustomToggles() {
  document.getElementById('toggleAddSourceBtn').addEventListener('click', () => {
    isAddingNewSource = !isAddingNewSource;
    document.getElementById('customSourceInputWrap').classList.toggle('hidden', !isAddingNewSource);
    document.getElementById('selectSourceWrap').classList.toggle('hidden', isAddingNewSource);
    document.getElementById('toggleAddSourceBtn').innerText = isAddingNewSource ? 'Choose Existing' : '+ Add New Source';
  });

  document.getElementById('toggleAddCategoryBtn').addEventListener('click', () => {
    isAddingNewCategory = !isAddingNewCategory;
    document.getElementById('customCategoryInputWrap').classList.toggle('hidden', !isAddingNewCategory);
    document.getElementById('selectCategoryWrap').classList.toggle('hidden', isAddingNewCategory);
    document.getElementById('toggleAddCategoryBtn').innerText = isAddingNewCategory ? 'Choose Existing' : '+ Add New Category';
  });

  document.getElementById('toggleAddNameBtn').addEventListener('click', () => {
    isAddingNewName = !isAddingNewName;
    document.getElementById('customNameInputWrap').classList.toggle('hidden', !isAddingNewName);
    document.getElementById('selectNameWrap').classList.toggle('hidden', isAddingNewName);
    document.getElementById('toggleAddNameBtn').innerText = isAddingNewName ? 'Choose Existing' : '+ Add New Person';
  });

  document.getElementById('toggleAddMethodBtn').addEventListener('click', () => {
    isAddingNewMethod = !isAddingNewMethod;
    document.getElementById('customMethodInputWrap').classList.toggle('hidden', !isAddingNewMethod);
    document.getElementById('selectMethodWrap').classList.toggle('hidden', isAddingNewMethod);
    document.getElementById('toggleAddMethodBtn').innerText = isAddingNewMethod ? 'Choose Existing' : '+ Add New Method';
  });

  document.getElementById('formMethod').addEventListener('change', (e) => {
    const tabName = document.getElementById('modalTargetTab').value;
    if (tabName === 'bankTxn') {
      populateBankNoteOptions(e.target.value);
    }
  });
}

async function handleSaveModal(e) {
  e.preventDefault();
  const submitButton = document.getElementById('saveModalSubmitBtn');
  if (submitButton.disabled) return;
  submitButton.disabled = true;
  const tabName = document.getElementById('modalTargetTab').value;
  const mode = document.getElementById('modalCurrentMode').value;
  const editingId = document.getElementById('editingId').value;
  const finalDate = formatToDisplayDate(document.getElementById('formDate').value);
  const rawAmount = document.getElementById('formAmount').value;
  const numericAmount = Number(rawAmount);
  if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
    alert('Amount must be greater than zero.');
    submitButton.disabled = false;
    return;
  }
  if (!document.getElementById('formDate').value) {
    alert('Please select a date and time.');
    submitButton.disabled = false;
    return;
  }

  // Resolve Custom Options
  let resolvedSource = document.getElementById('formSource').value;
  if (isAddingNewSource && document.getElementById('newCustomSource').value.trim()) {
    resolvedSource = document.getElementById('newCustomSource').value.trim();
    if (!DEFAULT_SOURCES.includes(resolvedSource)) {
      DEFAULT_SOURCES.push(resolvedSource);
      await saveMetaOption('source', resolvedSource);
    }
  }

  let resolvedCategory = document.getElementById('formCategory').value;
  if (isAddingNewCategory && document.getElementById('newCustomCategory').value.trim()) {
    resolvedCategory = document.getElementById('newCustomCategory').value.trim();
    if (!DEFAULT_CATEGORIES.includes(resolvedCategory)) {
      DEFAULT_CATEGORIES.push(resolvedCategory);
      await saveMetaOption('category', resolvedCategory);
    }
  }

  let resolvedName = document.getElementById('formName').value;
  if (isAddingNewName && document.getElementById('newCustomName').value.trim()) {
    resolvedName = document.getElementById('newCustomName').value.trim();
    if (!DEFAULT_NAMES.includes(resolvedName)) {
      DEFAULT_NAMES.push(resolvedName);
      await saveMetaOption('name', resolvedName);
    }
  }

  let resolvedMethod = document.getElementById('formMethod').value;
  if (isAddingNewMethod && document.getElementById('newCustomMethod').value.trim()) {
    resolvedMethod = document.getElementById('newCustomMethod').value.trim();
    if (!DEFAULT_METHODS.includes(resolvedMethod)) {
      DEFAULT_METHODS.push(resolvedMethod);
      await saveMetaOption('method', resolvedMethod);
    }
  }

  if (tabName === 'bankTxn') {
    const previousNote = document.getElementById('formNote').value;
    populateBankNoteOptions(resolvedMethod);
    const noteSelect = document.getElementById('formNote');
    if ([...noteSelect.options].some(option => option.value === previousNote)) noteSelect.value = previousNote;
  }
  const formNote = document.getElementById('formNote').value;

  const payload = {
    type: tabName,
    date: finalDate,
    amount: numericAmount,
    method: resolvedMethod,
    source: resolvedSource,
    category: resolvedCategory,
    name: resolvedName,
    note: formNote,
    fromMethod: (formNote && formNote.startsWith('From ')) ? formNote.replace('From ', '').trim() : null
  };

  let resId = editingId;
  if (mode === 'add') {
    const res = await fetch('/api/records', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const d = await res.json();
    if (!res.ok || !d.success) throw new Error(d.error || d.message || 'Could not save record');
    resId = d.id;
  } else {
    const res = await fetch(`/api/records/${encodeURIComponent(editingId)}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const d = await res.json();
    if (!res.ok || !d.success) throw new Error(d.error || 'Could not update record');
  }

  highlightedId = resId;
  setTimeout(() => { highlightedId = null; }, 2500);

  closeModal();
  await fetchAllRecords();
  submitButton.disabled = false;
}

async function saveMetaOption(type, value) {
  const res = await fetch('/api/meta', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type, value })
  });
  const data = await res.json();
  if (!res.ok || !data.success) throw new Error(data.error || 'Could not save custom option');
}

async function deleteRecord(id, kind) {
  const labels = { income: 'income', expense: 'expense', payable: 'payable', receivable: 'receivable', bankTxn: 'cash/bank transaction' };
  const label = labels[kind] || 'record';
  if (!confirm(`এই ${label} এন্ট্রিটি স্থায়ীভাবে মুছে ফেলবেন?\n\nএন্ট্রির সাথে যুক্ত settlement/history-ও মুছে যাবে। Dashboard, balance ও সব calculation থেকে এটি বাদ যাবে।`)) return;
  try {
    const response = await fetch(`/api/records/${encodeURIComponent(id)}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error || 'এন্ট্রি মুছতে সমস্যা হয়েছে।');
    await fetchAllRecords();
    alert('এন্ট্রি মুছে ফেলা হয়েছে এবং database compact করা হয়েছে।');
  } catch (error) {
    console.error(error);
    alert(error.message || 'এন্ট্রি মুছতে সমস্যা হয়েছে।');
  }
}

async function addSettlement(id, account, outstanding, kind) {
  const label = kind === 'payable' ? 'পরিশোধের পরিমাণ' : 'ফেরত পাওয়া টাকার পরিমাণ';
  const raw = prompt(`${label} (সর্বোচ্চ ৳${Number(outstanding).toLocaleString()})`, String(outstanding));
  if (raw === null) return;
  const amount = Number(raw);
  if (!Number.isFinite(amount) || amount <= 0 || amount > Number(outstanding) + 0.001) { alert('সঠিক পরিমাণ লিখুন।'); return; }
  const selectedAccount = prompt('কোন অ্যাকাউন্টে/থেকে এই লেনদেন হবে? (Account name)', account);
  if (selectedAccount === null || !selectedAccount.trim()) return;
  const date = localDateTimeValue();
  const res = await fetch(`/api/records/${encodeURIComponent(id)}/settlements`, {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({amount, method: selectedAccount.trim(), date})
  });
  const data = await res.json();
  if (!res.ok) { alert(data.error || 'Could not save settlement'); return; }
  await fetchAllRecords();
}

// Navigation & Tab Switching
function switchTab(newTab) {
  if (currentUser?.role === 'master_admin') return;
  const allowedTabs = ['dashboard', 'income', 'expenses', 'payables', 'receivables', 'cashBanks'];
  if (!allowedTabs.includes(newTab)) return;
  activeTab = newTab;

  // Toggle active class on desktop tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    const isThis = btn.getAttribute('data-tab') === newTab;
    btn.classList.toggle('active-tab', isThis);
    if (isThis) {
      btn.classList.remove('text-emerald-100', 'hover:bg-emerald-900/60', 'hover:text-white');
      const icon = btn.querySelector('svg');
      if (icon) icon.classList.add('text-[#004d3d]');
    } else {
      btn.classList.add('text-emerald-100', 'hover:bg-emerald-900/60', 'hover:text-white');
      const icon = btn.querySelector('svg');
      if (icon) icon.classList.remove('text-[#004d3d]');
    }
  });

  // Toggle active styling on mobile floating bottom nav and drawer nav.
  document.querySelectorAll('.mobile-tab-btn').forEach(btn => {
    const isThis = btn.getAttribute('data-tab') === newTab;
    btn.classList.toggle('text-[#004d3d]', isThis);
    btn.classList.toggle('font-black', isThis);
    btn.classList.toggle('text-slate-400', !isThis);
    btn.classList.toggle('font-medium', !isThis);
    btn.setAttribute('aria-current', isThis ? 'page' : 'false');
  });
  document.querySelectorAll('.drawer-tab-btn').forEach(btn => {
    const isThis = btn.getAttribute('data-tab') === newTab;
    btn.classList.toggle('bg-white', isThis);
    btn.classList.toggle('text-[#004d3d]', isThis);
    btn.classList.toggle('shadow-md', isThis);
    btn.classList.toggle('text-emerald-100', !isThis);
    btn.classList.toggle('hover:bg-emerald-900/60', !isThis);
    btn.classList.toggle('hover:text-white', !isThis);
    btn.setAttribute('aria-current', isThis ? 'page' : 'false');
  });

  // Toggle tab sections
  const tabIds = ['dashboard', 'income', 'expenses', 'payables', 'receivables', 'cashBanks'];
  tabIds.forEach(t => {
    const el = document.getElementById(`tab-${t}`);
    if (el) {
      el.classList.toggle('hidden', t !== newTab);
      if (t === newTab) {
        el.classList.remove('tab-enter');
        void el.offsetWidth;
        el.classList.add('tab-enter');
      }
    }
  });

  // Close mobile drawer if opened
  closeMobileDrawer();

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function openMobileDrawer() {
  document.getElementById('mobileDrawerBackdrop').classList.remove('hidden');
}

function closeMobileDrawer() {
  document.getElementById('mobileDrawerBackdrop').classList.add('hidden');
}

async function readApiJson(response) {
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    const body = await response.text();
    const detail = body.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 220);
    throw new Error(`Server JSON response পাওয়া যায়নি (HTTP ${response.status}). ${detail || 'Please check the Flask route/server logs.'}`);
  }
  return response.json();
}

async function loadMasterAdminPanel() {
  const summary = document.getElementById('masterAdminSummary');
  const tbody = document.getElementById('masterAdminUsers');
  if (!summary || !tbody) return;
  try {
    const response = await fetch('/api/master-admin/overview');
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Admin data load failed');
    summary.textContent = `Total registered users: ${data.users.length}`;
    tbody.innerHTML = data.users.map(user => `<tr class="border-t align-top"><td class="p-3" data-label="Full name"><button type="button" data-admin-action="view" data-user-id="${escapeHtml(user.id)}" class="font-bold text-emerald-800 underline underline-offset-2 hover:text-emerald-950">${escapeHtml(user.full_name || '—')}</button></td><td class="p-3 break-all" data-label="Email address">${escapeHtml(user.email || '—')}</td><td class="p-3" data-label="Phone number">${escapeHtml(user.phone || '—')}</td><td class="p-3" data-label="Signup date">${escapeHtml(user.created_at || '—')}</td><td class="p-3" data-label="Role">${escapeHtml(user.role || 'user')}</td><td class="p-3" data-label="Status">${escapeHtml(user.status || '—')}</td><td class="p-3" data-label="Action">${user.role === 'master_admin' ? 'Protected' : `${user.status === 'active' ? `<button data-admin-action=\"suspend\" data-user-id=\"${escapeHtml(user.id)}\" class=\"rounded bg-rose-100 text-rose-700 px-3 py-2 font-bold whitespace-nowrap\">Suspend</button>` : `<button data-admin-action=\"activate\" data-user-id=\"${escapeHtml(user.id)}\" class=\"rounded bg-emerald-100 text-emerald-700 px-3 py-2 font-bold whitespace-nowrap\">Activate</button>`} <button data-admin-action=\"delete\" data-user-id=\"${escapeHtml(user.id)}\" class=\"mt-1 rounded bg-rose-700 text-white px-3 py-2 font-bold whitespace-nowrap\">Delete permanently</button>`}</td></tr>`).join('');
    await loadMasterAdminEmailProtection();
  } catch (error) { summary.textContent = error.message || 'Admin data unavailable'; }
}

async function loadMasterAdminUserData(userId) {
  const panel = document.getElementById('masterAdminUserDetail');
  if (!panel) return;
  panel.classList.remove('hidden'); panel.classList.add('admin-detail-enter');
  panel.innerHTML = '<p class="text-sm font-bold text-slate-600">Loading user finance data...</p>';
  try {
    const response = await fetch(`/api/master-admin/users/${encodeURIComponent(userId)}/data`);
    const data = await readApiJson(response);
    if (!response.ok || !data.success) throw new Error(data.message || 'User data load failed');
    const user = data.user;
    const groups = [
      ['Dashboard', data.records], ['Income', data.records.filter(x => x.type === 'income')],
      ['Expense', data.records.filter(x => x.type === 'expense')], ['Receivables', data.records.filter(x => x.type === 'receivable')],
      ['Payables', data.records.filter(x => x.type === 'payable')], ['Cash & Banks', data.records.filter(x => x.type === 'bankTxn')]
    ];
    const total = type => data.records.filter(x => x.type === type).reduce((sum,x) => sum + (Number(x.amount)||0),0);
    const money = n => `৳${Number(n||0).toLocaleString()}`;
    panel.innerHTML = `<div class="flex flex-wrap items-start justify-between gap-3 mb-4"><div><h3 class="font-black text-emerald-950 text-lg">${escapeHtml(user.full_name)} · Finance Overview</h3><p class="text-xs text-slate-600">${escapeHtml(user.email)} · ${escapeHtml(user.phone || 'No phone')} · ${escapeHtml(user.status)}</p></div><button type="button" id="closeAdminUserDetail" class="rounded-lg border bg-white px-3 py-2 text-xs font-bold">Close</button></div>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">${[['Income',total('income')],['Expense',total('expense')],['Receivable',total('receivable')],['Payable',total('payable')]].map(([label,value])=>`<div class="rounded-lg bg-white border p-3"><div class="text-[11px] text-slate-500">${label}</div><div class="font-black text-slate-900">${money(value)}</div></div>`).join('')}</div>
      ${groups.map(([title,rows])=>`<section class="bg-white border rounded-xl p-3 mb-3"><h4 class="font-black text-sm mb-2">${title} <span class="text-xs text-slate-500">(${rows.length})</span></h4>${rows.length ? `<div class="overflow-x-auto"><table class="w-full text-xs"><thead><tr class="text-left text-slate-500"><th class="p-2">Date</th><th class="p-2">Type</th><th class="p-2">Description</th><th class="p-2 text-right">Amount</th><th class="p-2">Method</th><th class="p-2">Status</th></tr></thead><tbody>${rows.map(r=>`<tr class="border-t"><td class="p-2 whitespace-nowrap">${escapeHtml(r.date||'')}</td><td class="p-2">${escapeHtml(r.type||'')}</td><td class="p-2">${escapeHtml(r.source||r.category||r.name||r.note||'—')}</td><td class="p-2 text-right font-bold">${money(r.amount)}</td><td class="p-2">${escapeHtml(r.method||'')}</td><td class="p-2">${escapeHtml(r.status||'—')}</td></tr>`).join('')}</tbody></table></div>` : '<p class="text-xs text-slate-400">No entries.</p>'}</section>`).join('')}
      <section class="bg-white border rounded-xl p-3"><h4 class="font-black text-sm mb-2">Settlement History (${data.settlements.length})</h4>${data.settlements.length ? data.settlements.map(st=>`<div class="border-t py-2 text-xs flex flex-wrap justify-between gap-2"><span>${escapeHtml(st.date)} · ${escapeHtml(st.record_type)} · ${escapeHtml(st.record_name||'')}</span><strong>${money(st.amount)} · ${escapeHtml(st.method)}</strong></div>`).join('') : '<p class="text-xs text-slate-400">No settlements.</p>'}</section>`;
    document.getElementById('closeAdminUserDetail')?.addEventListener('click',()=>{panel.classList.add('hidden');panel.innerHTML='';});
    panel.scrollIntoView({behavior:'smooth',block:'start'});
  } catch (error) { panel.innerHTML = `<p class="text-sm text-rose-700">${escapeHtml(error.message || 'Unable to load user data.')}</p>`; }
}

async function loadMasterAdminEmailProtection() {
  const stats = document.getElementById('masterAdminEmailStats');
  const rules = document.getElementById('masterAdminEmailRules');
  if (!stats || !rules) return;
  try {
    const response = await fetch('/api/master-admin/email-protection');
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Email protection data unavailable');
    stats.textContent = `${Number(data.known_disposable_domains).toLocaleString()} known disposable domains · Auto-update every 24 hours · Last update: ${data.last_updated || 'Not yet updated'}`;
    rules.innerHTML = data.custom_rules.length ? '<div class="font-bold mb-1">Custom rules:</div>' + data.custom_rules.map(rule => `<div class="flex flex-wrap gap-2 py-1"><span>${escapeHtml(rule.domain)}</span><span class="font-bold ${rule.rule === 'block' ? 'text-rose-700' : 'text-emerald-700'}">${rule.rule.toUpperCase()}</span><span class="text-slate-400">${escapeHtml(rule.updated_at || '')}</span></div>`).join('') : 'No custom domain rules.';
  } catch (error) { stats.textContent = error.message || 'Email protection data unavailable'; }
}

// Event Listeners Setup
function setupEventListeners() {
  setupModalCustomToggles();
  document.getElementById('refreshMasterAdminBtn')?.addEventListener('click', loadMasterAdminPanel);
  document.getElementById('refreshDisposableDomainsBtn')?.addEventListener('click', async () => {
    const button = document.getElementById('refreshDisposableDomainsBtn'); button.disabled = true;
    try { const res = await fetch('/api/master-admin/email-protection/refresh', {method:'POST'}); const data = await res.json(); if (!res.ok) throw new Error(data.message || data.error || 'Update failed'); await loadMasterAdminEmailProtection(); alert(data.updated ? `Database updated: ${Number(data.domains).toLocaleString()} domains.` : 'Remote sources unavailable or no changes. Local database retained.'); }
    catch (err) { alert(err.message); } finally { button.disabled = false; }
  });
  document.getElementById('saveAdminEmailDomainRuleBtn')?.addEventListener('click', async () => {
    const domain = document.getElementById('adminEmailDomainInput').value.trim();
    const action = document.getElementById('adminEmailDomainAction').value;
    if (!domain) return alert('একটি Domain লিখুন।');
    try { const res = await fetch('/api/master-admin/email-protection/rules', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({domain,action})}); const data = await res.json(); if (!res.ok) throw new Error(data.message || data.error || 'Rule save failed'); document.getElementById('adminEmailDomainInput').value = ''; await loadMasterAdminEmailProtection(); } catch (err) { alert(err.message); }
  });
  document.getElementById('masterAdminUsers')?.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-admin-action]'); if (!button) return;
    const action = button.dataset.adminAction; const userId = button.dataset.userId;
    if (action === 'view') { await loadMasterAdminUserData(userId); return; }
    if (action === 'delete') {
      if (!confirm('এই User-এর account, income, expense, receivable, payable, bank transaction, settlement এবং custom options স্থায়ীভাবে delete হবে। এই কাজ Undo করা যাবে না। Continue?')) return;
      try {
        const res = await fetch(`/api/master-admin/users/${encodeURIComponent(userId)}`, {method:'DELETE'});
        const data = await readApiJson(res); if (!res.ok || !data.success) throw new Error(data.message || 'Permanent deletion failed');
        const detail = document.getElementById('masterAdminUserDetail'); if (detail) { detail.classList.add('hidden'); detail.innerHTML = ''; }
        await loadMasterAdminPanel(); alert('User এবং তার সব associated data database থেকে permanently delete হয়েছে; SQLite file compact করা হয়েছে.');
      } catch (err) { alert(err.message); }
      return;
    }
    if (action === 'suspend' && !confirm('এই Account suspend করবেন?')) return;
    try { const res = await fetch(`/api/master-admin/users/${encodeURIComponent(userId)}/${action}`, {method:'POST'}); const data = await readApiJson(res); if (!res.ok) throw new Error(data.message || data.error || 'Action failed'); await loadMasterAdminPanel(); if (action === 'suspend') alert('Account suspended.'); } catch (err) { alert(err.message); }
  });

  document.getElementById('entryForm').addEventListener('submit', async (e) => {
    try { await handleSaveModal(e); }
    catch (err) { console.error(err); alert(err.message || 'Unable to save. Please try again.'); }
    finally { document.getElementById('saveModalSubmitBtn').disabled = false; }
  });

  // Signup / Login
  const authError = (message) => {
    document.getElementById('authErrorMsg').classList.remove('hidden');
    document.getElementById('authErrorText').innerText = message || 'কাজটি সম্পন্ন করা যায়নি।';
  };
  const clearAuthError = () => {
    const box = document.getElementById('authErrorMsg');
    box.className = 'hidden mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-bold';
  };
  const showAuthMode = (mode) => {
    clearAuthError();
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    loginForm.classList.toggle('hidden', mode !== 'login');
    signupForm.classList.toggle('hidden', mode !== 'signup');
    const activeForm = mode === 'login' ? loginForm : signupForm;
    activeForm.classList.remove('auth-form-enter');
    void activeForm.offsetWidth;
    activeForm.classList.add('auth-form-enter');
    document.getElementById('showLoginBtn').className = mode === 'login' ? 'auth-mode-btn py-2.5 rounded-lg bg-[#004d3d] text-white text-sm font-black' : 'auth-mode-btn py-2.5 rounded-lg text-slate-600 text-sm font-black';
    document.getElementById('showSignupBtn').className = mode === 'signup' ? 'auth-mode-btn py-2.5 rounded-lg bg-[#004d3d] text-white text-sm font-black' : 'auth-mode-btn py-2.5 rounded-lg text-slate-600 text-sm font-black';
  };
  const enterApp = async (user) => {
    currentUser = user;
    isAuthenticated = true;
    document.getElementById('authScreen').classList.add('hidden');
    document.getElementById('mainApp').classList.remove('hidden');
    document.getElementById('drawerUserLabel').innerText = `User: ${currentUser.name || currentUser.email}`;
    applyRoleLayout();
    if (currentUser.role === 'master_admin') {
      await loadMasterAdminPanel();
    } else {
      await loadMetaData();
      await fetchAllRecords();
    }
  };
  document.getElementById('showLoginBtn').addEventListener('click', () => showAuthMode('login'));
  document.getElementById('showSignupBtn').addEventListener('click', () => showAuthMode('signup'));

  document.getElementById('sendAdminOtpBtn').addEventListener('click', async () => {
    clearAuthError(); const btn = document.getElementById('sendAdminOtpBtn'); btn.disabled = true; btn.textContent = 'Code পাঠানো হচ্ছে...';
    try {
      const res = await fetch('/api/master-admin/request-code', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({})});
      const data = await res.json(); if (!res.ok || !data.success) throw new Error(data.message || 'OTP পাঠানো যায়নি।');
      document.getElementById('adminOtpArea').classList.remove('hidden'); authError('Please check your admin email. We sent a login code.');
      document.getElementById('authErrorMsg').className = 'mx-6 mt-4 p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700 text-xs font-bold';
      document.getElementById('adminOtpCode').focus();
    } catch(err) { authError(err.message); }
    finally { btn.disabled = false; btn.textContent = 'আবার Code পাঠান'; }
  });
  document.getElementById('verifyAdminOtpBtn').addEventListener('click', async () => {
    clearAuthError(); const btn = document.getElementById('verifyAdminOtpBtn'); btn.disabled = true; btn.textContent = 'যাচাই করা হচ্ছে...';
    try {
      const res = await fetch('/api/master-admin/verify-code', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({code:document.getElementById('adminOtpCode').value.trim()})});
      const data = await res.json(); if (!res.ok || !data.success) throw new Error(data.message || 'Code যাচাই করা যায়নি।'); await enterApp(data.user);
    } catch(err) { authError(err.message); }
    finally { btn.disabled = false; btn.textContent = 'Code Verify করে Login করুন'; }
  });

  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault(); clearAuthError();
    const submitBtn = document.getElementById('loginSubmitBtn');
    submitBtn.disabled = true; submitBtn.textContent = 'যাচাই করা হচ্ছে...';
    try {
      const res = await fetch('/api/auth/login', { method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email: document.getElementById('loginUsername').value.trim(), password: document.getElementById('loginPassword').value }) });
      const data = await res.json();
      if (!res.ok || !data.success) throw new Error(data.message || 'ভুল Email অথবা Password।');
      await enterApp(data.user);
    } catch (err) { authError(err.message || 'সার্ভারে সংযোগ করা যায়নি।'); }
    finally { submitBtn.disabled = false; submitBtn.textContent = 'Login করুন'; }
  });

  document.getElementById('signupForm').addEventListener('submit', async (e) => {
    e.preventDefault(); clearAuthError();
    const submitBtn = document.getElementById('signupSubmitBtn');
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('signupConfirmPassword').value;
    if (password !== confirmPassword) { authError('Password এবং Confirm Password মিলছে না।'); return; }
    submitBtn.disabled = true; submitBtn.textContent = 'Sending verification code...';
    try {
      const res = await fetch('/api/auth/signup/request-code', { method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ fullName: document.getElementById('signupFullName').value.trim(), email: document.getElementById('signupEmail').value.trim(), phone: document.getElementById('signupPhone').value.trim(), password, confirmPassword }) });
      const data = await readApiJson(res);
      if (!res.ok || !data.success) throw new Error(data.message || data.error || 'Verification code পাঠানো যায়নি।')
      document.getElementById('signupOtpArea').classList.remove('hidden');
      document.getElementById('signupOtpArea').classList.remove('otp-area-enter');
      void document.getElementById('signupOtpArea').offsetWidth;
      document.getElementById('signupOtpArea').classList.add('otp-area-enter');
      document.getElementById('signupOtpCode').focus();
      submitBtn.textContent = 'Resend Verification Code';
    } catch (err) { authError(err.message || 'সার্ভারে সংযোগ করা যায়নি।'); }
    finally { submitBtn.disabled = false; }
  });

  document.getElementById('verifySignupOtpBtn').addEventListener('click', async () => {
    clearAuthError();
    const btn = document.getElementById('verifySignupOtpBtn');
    btn.disabled = true; btn.textContent = 'Verifying...';
    try {
      const res = await fetch('/api/auth/signup/verify-code', {method:'POST', headers:{'Content-Type':'application/json'},
        body:JSON.stringify({email:document.getElementById('signupEmail').value.trim(), code:document.getElementById('signupOtpCode').value.trim()})});
      const data = await readApiJson(res);
      if (!res.ok || !data.success) throw new Error(data.message || data.error || 'Email verification failed.');
      await enterApp(data.user);
    } catch (err) { authError(err.message || 'Email verification failed.'); }
    finally { btn.disabled = false; btn.textContent = 'Verify Email & Create Account'; }
  });

  // Main navigation: use delegation so desktop, drawer and bottom tabs all work.
  document.addEventListener('click', (event) => {
    const tabButton = event.target.closest('[data-tab]');
    if (tabButton) {
      event.preventDefault();
      switchTab(tabButton.getAttribute('data-tab'));
    }
  });

  // Mobile drawer controls.
  document.getElementById('openMobileMenuBtn').addEventListener('click', openMobileDrawer);
  document.getElementById('closeMobileMenuBtn').addEventListener('click', closeMobileDrawer);
  document.getElementById('mobileDrawerOverlay').addEventListener('click', closeMobileDrawer);
  document.getElementById('brandLogoBtn').addEventListener('click', () => switchTab('dashboard'));

  // Modal close/cancel controls.
  document.getElementById('closeModalBtn').addEventListener('click', closeModal);
  document.getElementById('cancelModalBtn').addEventListener('click', closeModal);
  document.getElementById('entryModal').addEventListener('click', (event) => {
    if (event.target.id === 'entryModal') closeModal();
  });

  // Search boxes were rendered but had no input handlers in the previous build.
  document.getElementById('incomeSearchInput').addEventListener('input', (event) => {
    searchTerms.income = event.target.value || '';
    renderIncomeTab();
  });
  document.getElementById('expenseSearchInput').addEventListener('input', (event) => {
    searchTerms.expense = event.target.value || '';
    renderExpensesTab();
  });
  document.getElementById('payableSearchInput').addEventListener('input', (event) => {
    searchTerms.payable = event.target.value || '';
    renderPayablesTab();
  });
  document.getElementById('receivableSearchInput').addEventListener('input', (event) => {
    searchTerms.receivable = event.target.value || '';
    renderReceivablesTab();
  });
  document.getElementById('bankTxnSearchInput').addEventListener('input', (event) => {
    searchTerms.bankTxn = event.target.value || '';
    renderCashBanksTab();
  });

  // Dashboard period filters must refresh all period-based summaries.
  document.getElementById('selectedMonth').addEventListener('change', (event) => {
    selectedMonth = event.target.value;
    renderAllViews();
  });
  document.getElementById('selectedYear').addEventListener('change', (event) => {
    selectedYear = event.target.value;
    renderAllViews();
  });

  // Logout
  const doLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    location.reload();
  };
  document.getElementById('logoutBtn').addEventListener('click', doLogout);
  document.getElementById('drawerLogoutBtn').addEventListener('click', doLogout);
}
